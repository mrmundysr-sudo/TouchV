package com.touchv.game;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * TouchV! - single Activity, eight-plate skin contract.
 *
 * Rules and the game loop live in GameEngine / Meld and are unchanged. This
 * class is presentation only: plates, overlays, motion, sound and pacing.
 *
 * Every visible beat is driven by a small step sequencer ({@link #after}) with
 * a cancellation token, so a turn always reads as a sequence: spotlight, draw
 * (card flies), think, discard (card flies and lands with a slap), hand-off.
 * While cards are in flight the table ignores input, so taps can never race
 * an animation or an AI turn.
 */
public class MainActivity extends Activity {

    // ------------------------------------------------------------------
    // Plate mark coordinates as fractions of the portrait plate.
    // Derived from the supplied marked plates; see README "marks" table.
    // ------------------------------------------------------------------
    private static final float[] TITLE_BOX = {0.182f, 0.772f, 0.699f, 0.116f};   // dirt box under wagon
    private static final float[] FAN_BOX    = {0.066f, 0.660f, 0.872f, 0.210f};  // mark 1: your cards
    private static final float[] DRAW_BOX   = {0.377f, 0.540f, 0.146f, 0.090f};  // mark 2: draw pile
    private static final float[] DISC_BOX   = {0.588f, 0.540f, 0.146f, 0.090f};  // mark 3: discard pile
    private static final float[] BUBBLE_BOX = {0.031f, 0.462f, 0.222f, 0.086f};  // mark 4: your score bubble
    private static final float[] PA_WIN_BOX = {0.010f, 0.706f, 0.340f, 0.112f};  // you-win mark 1
    private static final float[] PA_LOSE_BOX= {0.020f, 0.700f, 0.340f, 0.112f};  // try-again mark 1
    private static final float[] SC_GIRL    = {0.120f, 0.028f, 0.215f, 0.092f};  // score-card mark 1
    private static final float[] SC_BOY     = {0.632f, 0.033f, 0.215f, 0.092f};  // score-card mark 2
    private static final float[] SC_CAT     = {0.124f, 0.529f, 0.215f, 0.092f};  // score-card mark 3
    private static final float[] SC_ME      = {0.653f, 0.543f, 0.215f, 0.092f};  // score-card mark 4

    /** Opponent seat centres (fractions of the table plate), per opponent count. */
    private static final float[][] SEATS_1 = {{0.50f, 0.28f}};
    private static final float[][] SEATS_2 = {{0.24f, 0.27f}, {0.74f, 0.27f}};
    private static final float[][] SEATS_3 = {{0.21f, 0.27f}, {0.50f, 0.41f}, {0.79f, 0.27f}};

    /**
     * Pacing, in milliseconds. One place to tune the feel of the game.
     * Card flights land their sound on the frame of impact (see LAND_LEAD).
     */
    static final class Pace {
        // Round opening
        static final long BANNER_HOLD = 900;     // "ROUND 4" banner on screen before the shuffle
        static final long SHUFFLE = 520;         // riffle before the first card leaves the deck
        static final long DEAL_TOTAL = 1500;     // the whole deal fits in about this long
        static final long DEAL_GAP_MIN = 34;
        static final long DEAL_GAP_MAX = 95;
        static final long DEAL_FLIGHT = 300;
        static final long FLIP_DISCARD = 340;    // first discard turned up after the deal
        // Your turn
        static final long DRAW_FLIGHT = 320;
        static final long PARK_FLIGHT = 200;
        static final long DISCARD_FLIGHT = 300;
        static final long AFTER_YOUR_DISCARD = 420;
        static final long IDLE_HINT = 6000;      // nudge the piles if you sit idle
        // Opponents
        static final long AI_SPOTLIGHT = 340;
        static final long AI_DRAW_FLIGHT = 380;
        static final long AI_THINK_MIN = 380;
        static final long AI_THINK_MAX = 720;
        static final long AI_DISCARD_FLIGHT = 340;
        static final long AI_SETTLE = 260;
        // Moments
        static final long OUT_BANNER = 1250;
        static final long MELD_BEAT = 650;
        static final long ROUND_END_PAUSE = 750;
        static final long SCORE_COUNT = 750;
        // Sound lead: the slap in sfx_discard / snap in sfx_deal comes ~90/60 ms after onset.
        static final long DISCARD_LEAD = 92;
        static final long DEAL_LEAD = 62;
    }

    private static final Interpolator EASE = new PathInterpolator(0.25f, 0.1f, 0.2f, 1f);

    private GameEngine engine;
    private final Random rnd = new Random();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Sfx sfx;
    private CardFactory cards;

    /** Bumped to cancel every pending step and flight (pause, back, new game). */
    private int seq = 0;
    /** True while a sequence owns the table (cards moving, AI acting). */
    private boolean busy = false;
    private boolean dealing = false;
    private int fanReveal = Integer.MAX_VALUE;
    /** How many top discards to hide while a card is still flying onto the pile. */
    private int hideTop = 0;
    private boolean hideAllDiscards = false;
    private boolean raisedHidden = false;
    private int spotSeat = -1;
    private String statusOverride = null;
    private boolean roundSummaryMode = false;
    /** A new hand is dealt in the engine and waiting for its deal animation. */
    private boolean pendingDeal = false;

    private FrameLayout root;
    private PlateLayout screenTitle, screenTable, screenYouWin, screenTryAgain;
    private PlateLayout overlayScores, overlaySort, overlayMelds;
    private FrameLayout fxLayer;
    private LinearLayout banner;
    private Style.OutlineText bannerTitle;
    private TextView bannerSub;

    private PlateLayout fanBox;
    private LinearLayout fanTop, fanBottom;
    private FrameLayout drawPile, discardPile;
    private TextView drawCaption;
    private ImageView tablePlate;
    private TurnGlowView turnGlow;
    private TextView labelRound, labelWild, labelStatus, labelScores;
    private TextView cloudScore;
    private View cloudPlayer;
    private LinearLayout meldPlayer;
    private Style.OutlineText btnDeclareOut, btnLayMelds, btnParkEnd;
    private ConfettiView confetti;
    private TextView resultStripWin, resultStripLose;
    private final List<ImageView> muteButtons = new ArrayList<>();
    private TextView scoreGirl, scoreBoy, scoreCat, scorePlayer;

    private final List<View> fanViews = new ArrayList<>();
    private View raisedView;
    private int selectedHandIndex = -1;
    private int lastLifted = -1;
    private int drawnHandIndex = -1;
    private int sortSelected = -1;

    private GestureDetector swipeUp;
    private final Runnable idleHint = this::playIdleHint;

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Style.init(this);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sfx = new Sfx(this);
        cards = new CardFactory(this);
        swipeUp = createSwipeUp();
        engine = new GameEngine(rnd);
        buildUi();
        showTitle(false);
    }

    private GestureDetector createSwipeUp() {
        return new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null) return false;
                return (e2.getY() - e1.getY()) < -dp(28) && Math.abs(vy) >= Math.abs(vx);
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void goFullscreen() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goFullscreen();
    }

    /** Stop every sequence so the game can never advance behind the player's back. */
    @Override
    protected void onPause() {
        super.onPause();
        cancelFlow();
        if (sfx != null) sfx.pauseAll();
        if (turnGlow != null) turnGlow.setSpot(-1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        goFullscreen();
        if (sfx != null) sfx.resumeAll();
        if (engine == null || screenTable == null) return;
        if (screenTitle.getVisibility() == View.VISIBLE && screenTable.getVisibility() != View.VISIBLE) {
            // A pick may have been interrupted mid-transition: restore the title.
            showTitle(false);
            return;
        }
        for (PlateLayout r : new PlateLayout[]{screenYouWin, screenTryAgain}) {
            if (r.getVisibility() == View.VISIBLE) {
                View pa = r.findViewById(R.id.btn_play_again);
                pa.setVisibility(View.VISIBLE);
                pa.setAlpha(1f);
                pa.setScaleX(1f);
                pa.setScaleY(1f);
                (r == screenYouWin ? resultStripWin : resultStripLose).setAlpha(1f);
                return;
            }
        }
        if (screenTable.getVisibility() != View.VISIBLE) return;
        if (pendingDeal) {
            overlayScores.setVisibility(View.GONE);
            overlayScores.setTranslationY(0f);
            dealRound();
            return;
        }
        if (overlayScores.getVisibility() != View.VISIBLE
                && overlayMelds.getVisibility() != View.VISIBLE) {
            refreshTable();
            continueFlow(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cancelFlow();
        if (sfx != null) sfx.release();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (overlaySort.getVisibility() == View.VISIBLE) { closeSortOverlay(); return; }
        if (overlayMelds.getVisibility() == View.VISIBLE) { closeMeldOverlay(); return; }
        if (overlayScores.getVisibility() == View.VISIBLE) {
            if (!roundSummaryMode) dismissScores();
            return;
        }
        if (screenTable.getVisibility() == View.VISIBLE) { showTitle(true); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------
    // Sequencer
    // ------------------------------------------------------------------

    /** Run {@code r} after {@code ms}, unless the flow is cancelled meanwhile. */
    private void after(long ms, Runnable r) {
        final int token = seq;
        handler.postDelayed(() -> {
            if (token == seq) r.run();
        }, Math.max(0, ms));
    }

    /** Run once the next layout pass has placed freshly rendered views. */
    private void afterLayout(Runnable r) {
        final int token = seq;
        final ViewTreeObserver vto = root.getViewTreeObserver();
        vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                if (root.getViewTreeObserver().isAlive()) {
                    root.getViewTreeObserver().removeOnPreDrawListener(this);
                }
                if (token == seq) r.run();
                return true;
            }
        });
        root.invalidate();
    }

    private void cancelFlow() {
        seq++;
        handler.removeCallbacksAndMessages(null);
        if (fxLayer != null) {
            List<View> kids = new ArrayList<>();
            for (int i = 0; i < fxLayer.getChildCount(); i++) kids.add(fxLayer.getChildAt(i));
            for (View k : kids) {
                Object a = k.getTag();
                if (a instanceof Animator) ((Animator) a).cancel();
            }
            fxLayer.removeAllViews();
        }
        busy = false;
        dealing = false;
        fanReveal = Integer.MAX_VALUE;
        hideTop = 0;
        hideAllDiscards = false;
        raisedHidden = false;
        statusOverride = null;
        spotSeat = -1;
        if (banner != null) {
            banner.animate().cancel();
            banner.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------------
    // UI construction
    // ------------------------------------------------------------------

    private void buildUi() {
        goFullscreen();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        buildTitleScreen();
        buildTableScreen();
        buildResultPlates();
        buildSortOverlay();
        buildScoreOverlay();
        buildMeldOverlay();
    }

    private ImageView plate(int drawableId) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        iv.setImageResource(drawableId);
        return iv;
    }

    private void add(PlateLayout parent, View child, float[] box) {
        parent.add(child, box[0], box[1], box[2], box[3]);
    }

    private PlateLayout fullScreen(int id) {
        PlateLayout p = new PlateLayout(this);
        p.setId(id);
        root.addView(p, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return p;
    }

    private ImageView muteButton() {
        ImageView b = new ImageView(this);
        b.setBackground(Style.pill(this));
        int p = dp(7);
        b.setPadding(p, p, p, p);
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setContentDescription("Sound on or off");
        b.setOnClickListener(v -> {
            sfx.setMuted(!sfx.isMuted());
            updateMuteIcons();
            if (!sfx.isMuted()) sfx.play(Sfx.TAP);
            tapHaptic(v);
        });
        Style.pressable(b);
        muteButtons.add(b);
        return b;
    }

    private void updateMuteIcons() {
        for (ImageView b : muteButtons) {
            b.setImageResource(sfx.isMuted() ? R.drawable.ic_sound_off : R.drawable.ic_sound_on);
            b.setAlpha(sfx.isMuted() ? 0.75f : 1f);
        }
    }

    // --- title: the plate IS the 1/2/3 pick ---------------------------

    private void buildTitleScreen() {
        screenTitle = fullScreen(R.id.screen_title);
        screenTitle.add(plate(R.drawable.bg_title), 0f, 0f, 1f, 1f);

        float w = TITLE_BOX[2] / 3f;
        View o1 = makeOpponentChoice(R.id.btn_opp_1, 1);
        View o2 = makeOpponentChoice(R.id.btn_opp_2, 2);
        View o3 = makeOpponentChoice(R.id.btn_opp_3, 3);
        add(screenTitle, o1, new float[]{TITLE_BOX[0], TITLE_BOX[1], w, TITLE_BOX[3]});
        add(screenTitle, o2, new float[]{TITLE_BOX[0] + w, TITLE_BOX[1], w, TITLE_BOX[3]});
        add(screenTitle, o3, new float[]{TITLE_BOX[0] + 2f * w, TITLE_BOX[1], w, TITLE_BOX[3]});
        o1.setOnClickListener(v -> onPickOpponents(v, 1));
        o2.setOnClickListener(v -> onPickOpponents(v, 2));
        o3.setOnClickListener(v -> onPickOpponents(v, 3));

        TextView hint = Style.label(this, Style.ui, 14, Style.CREAM);
        hint.setText("How many friends will you play?");
        hint.setBackground(Style.pill(this));
        hint.setPadding(dp(14), dp(6), dp(14), dp(6));
        screenTitle.add(hint, 0.14f, 0.900f, 0.72f, 0.038f);

        screenTitle.add(muteButton(), 0.865f, 0.012f, 0.11f, 0.044f);
        updateMuteIcons();
    }

    private View makeOpponentChoice(int id, int count) {
        PlateLayout choice = new PlateLayout(this);
        choice.setId(id);
        choice.setClickable(true);
        choice.setContentDescription("Play against " + count + (count == 1 ? " opponent" : " opponents"));
        float cardW = count == 1 ? 0.50f : (count == 2 ? 0.40f : 0.36f);
        float cardH = 0.80f;
        float spread = count == 2 ? 0.20f : 0.19f;
        for (int i = 0; i < count; i++) {
            View back = cards.back();
            back.setClickable(false);
            back.setRotation(count == 1 ? 0f : (i - (count - 1) / 2f) * (count == 2 ? 13f : 17f));
            float x = 0.5f - cardW / 2f + (i - (count - 1) / 2f) * spread;
            choice.add(back, x, 0.02f, cardW, cardH);
        }
        Style.OutlineText n = Style.headline(this, String.valueOf(count), 22);
        choice.add(n, 0.30f, 0.62f, 0.40f, 0.40f);
        Style.pressable(choice);
        return choice;
    }

    /** Gentle idle float on the three title choices. */
    private void startTitleIdle() {
        int[] ids = {R.id.btn_opp_1, R.id.btn_opp_2, R.id.btn_opp_3};
        for (int i = 0; i < ids.length; i++) {
            View v = screenTitle.findViewById(ids[i]);
            if (v == null) continue;
            Object old = v.getTag();
            if (old instanceof Animator) ((Animator) old).cancel();
            v.setTranslationY(0);
            ObjectAnimator a = ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, 0f, -dp(5), 0f);
            a.setDuration(2200);
            a.setStartDelay(i * 260L);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
            a.start();
            v.setTag(a);
        }
    }

    private void stopTitleIdle() {
        int[] ids = {R.id.btn_opp_1, R.id.btn_opp_2, R.id.btn_opp_3};
        for (int id : ids) {
            View v = screenTitle.findViewById(id);
            if (v != null && v.getTag() instanceof Animator) ((Animator) v.getTag()).cancel();
        }
    }

    // --- table: three plates, same four overlays -----------------------

    private void buildTableScreen() {
        screenTable = fullScreen(R.id.screen_table);
        tablePlate = plate(R.drawable.bg_table_1);
        screenTable.add(tablePlate, 0f, 0f, 1f, 1f);
        turnGlow = new TurnGlowView();
        screenTable.add(turnGlow, 0f, 0f, 1f, 1f);

        // HUD: round pill, wild pill, mute, status pill.
        labelRound = hudPill(R.id.label_round, 13);
        labelWild = hudPill(R.id.label_wild, 13);
        labelWild.setTextColor(Style.GOLD_LIGHT);
        screenTable.add(labelRound, 0.025f, 0.014f, 0.30f, 0.036f);
        screenTable.add(labelWild, 0.340f, 0.014f, 0.515f, 0.036f);
        screenTable.add(muteButton(), 0.865f, 0.012f, 0.11f, 0.040f);

        labelStatus = hudPill(R.id.label_status, 15);
        labelStatus.setTextColor(Style.CREAM);
        screenTable.add(labelStatus, 0.05f, 0.058f, 0.90f, 0.042f);

        // Mark 2: draw pile (stacked backs for depth) + caption.
        drawPile = new FrameLayout(this);
        drawPile.setId(R.id.draw_pile);
        drawPile.setContentDescription("Draw pile");
        drawPile.setClipChildren(false);
        for (int i = 2; i >= 0; i--) {
            View b = cards.back();
            b.setTranslationX(dp(i * 1.5f));
            b.setTranslationY(dp(i * 1.5f));
            drawPile.addView(b, match());
        }
        add(screenTable, drawPile, DRAW_BOX);
        drawPile.setOnClickListener(v -> onDrawTapped());

        drawCaption = pileCaption();
        screenTable.add(drawCaption, DRAW_BOX[0] - 0.03f, DRAW_BOX[1] + DRAW_BOX[3] + 0.006f,
                DRAW_BOX[2] + 0.06f, 0.024f);

        // Mark 3: discard pile.
        discardPile = new FrameLayout(this);
        discardPile.setId(R.id.discard_pile);
        discardPile.setContentDescription("Discard pile");
        discardPile.setClipChildren(false);
        add(screenTable, discardPile, DISC_BOX);
        discardPile.setOnClickListener(v -> onDiscardTapped());
        TextView discCaption = pileCaption();
        discCaption.setText("DISCARD");
        screenTable.add(discCaption, DISC_BOX[0] - 0.03f, DISC_BOX[1] + DISC_BOX[3] + 0.006f,
                DISC_BOX[2] + 0.06f, 0.024f);

        // Mark 4: your score bubble.
        LinearLayout bubble = new LinearLayout(this);
        bubble.setId(R.id.cloud_player);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(Style.panel(this));
        bubble.setContentDescription("Your score. Tap for the score card.");
        TextView cap = Style.label(this, Style.bold, 10, Style.GOLD_LIGHT);
        cap.setText("YOUR SCORE");
        cap.setLetterSpacing(0.08f);
        cloudScore = Style.headline(this, "0", 22);
        ((Style.OutlineText) cloudScore).gradient(0xFFFFFFFF, Style.GOLD_LIGHT);
        bubble.addView(cap, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        bubble.addView(cloudScore, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        bubble.setOnClickListener(v -> onOwnBubbleTapped());
        Style.pressable(bubble);
        cloudPlayer = bubble;
        add(screenTable, bubble, new float[]{BUBBLE_BOX[0], BUBBLE_BOX[1] + 0.008f,
                BUBBLE_BOX[2] - 0.01f, BUBBLE_BOX[3] - 0.016f});

        // Hidden opponent-cloud / seat hooks kept for a later pass.
        int[] hiddenIds = {R.id.cloud_opp_boy, R.id.cloud_opp_cat, R.id.cloud_opp_girl,
                R.id.slot_opp_boy, R.id.slot_opp_cat, R.id.slot_opp_girl,
                R.id.count_player, R.id.portrait_player,
                R.id.meld_opp_boy, R.id.meld_opp_cat, R.id.meld_opp_girl};
        for (int id : hiddenIds) add(screenTable, hidden(id), new float[]{0f, 0f, 0f, 0f});

        // Own meld tray (hidden until a laydown).
        meldPlayer = new LinearLayout(this);
        meldPlayer.setId(R.id.meld_player);
        meldPlayer.setOrientation(LinearLayout.HORIZONTAL);
        meldPlayer.setGravity(Gravity.CENTER);
        add(screenTable, meldPlayer, new float[]{0.10f, 0.630f, 0.80f, 0.026f});

        // Mark 1: your cards. Two-row fan (7 + 6) plus the raised drawn card.
        fanBox = new PlateLayout(this);
        fanBox.setId(R.id.fan);
        screenTable.add(fanBox, FAN_BOX[0], FAN_BOX[1], FAN_BOX[2], FAN_BOX[3]);

        fanTop = new LinearLayout(this);
        fanTop.setId(R.id.fan_top_row);
        fanTop.setOrientation(LinearLayout.HORIZONTAL);
        fanTop.setGravity(Gravity.CENTER_HORIZONTAL);
        fanTop.setClipChildren(false);
        fanBox.add(fanTop, 0f, 0f, 1f, 0.52f);

        fanBottom = new LinearLayout(this);
        fanBottom.setId(R.id.fan_bottom_row);
        fanBottom.setOrientation(LinearLayout.HORIZONTAL);
        fanBottom.setGravity(Gravity.CENTER_HORIZONTAL);
        fanBottom.setClipChildren(false);
        fanBox.add(fanBottom, 0f, 0.50f, 1f, 0.52f);

        // Rule buttons (no plate mark exists for these).
        btnDeclareOut = Style.candy(this, "DECLARE OUT", Style.Candy.GOLD, 16);
        btnDeclareOut.setId(R.id.btn_declare_out);
        btnLayMelds = Style.candy(this, "LAY MELDS", Style.Candy.GREEN, 16);
        btnLayMelds.setId(R.id.btn_lay_melds);
        btnParkEnd = Style.candy(this, "KEEP AT END", Style.Candy.PLUM, 15);
        btnParkEnd.setId(R.id.btn_park_end);
        add(screenTable, btnDeclareOut, new float[]{0.030f, 0.900f, 0.30f, 0.056f});
        add(screenTable, btnLayMelds, new float[]{0.350f, 0.900f, 0.30f, 0.056f});
        add(screenTable, btnParkEnd, new float[]{0.670f, 0.900f, 0.30f, 0.056f});
        btnDeclareOut.setOnClickListener(v -> onDeclareOut());
        btnLayMelds.setOnClickListener(v -> onLayMelds());
        btnParkEnd.setOnClickListener(v -> onParkEnd());
        btnDeclareOut.setVisibility(View.GONE);
        btnLayMelds.setVisibility(View.GONE);
        btnParkEnd.setVisibility(View.GONE);

        // Round banner.
        banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setGravity(Gravity.CENTER);
        banner.setClickable(false);
        bannerTitle = Style.headline(this, "ROUND 1", 50);
        bannerSub = Style.label(this, Style.ui, 16, Style.CREAM);
        bannerSub.setBackground(Style.pill(this));
        bannerSub.setPadding(dp(16), dp(7), dp(16), dp(7));
        banner.addView(bannerTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sl.topMargin = dp(4);
        banner.addView(bannerSub, sl);
        banner.setVisibility(View.GONE);
        screenTable.add(banner, 0f, 0.37f, 1f, 0.16f);

        // Flight layer for moving cards: last child, so it draws above everything.
        fxLayer = new FrameLayout(this);
        fxLayer.setClipChildren(false);
        screenTable.add(fxLayer, 0f, 0f, 1f, 1f);

        // Swipe up on the felt or the fan opens the sort overlay; a tap on empty
        // fan space releases a locked card.
        installGestures(tablePlate, this::openSortOverlay, null);
        installGestures(fanBox, this::openSortOverlay, this::onEmptyFanTapped);

        screenTable.setVisibility(View.GONE);
    }

    private TextView hudPill(int id, float sp) {
        TextView t = Style.label(this, Style.ui, sp, Style.CREAM);
        t.setId(id);
        t.setBackground(Style.pill(this));
        t.setPadding(dp(12), 0, dp(12), 0);
        t.setMaxLines(1);
        t.setAutoSizeTextTypeUniformWithConfiguration(9, (int) sp, 1, TypedValue.COMPLEX_UNIT_SP);
        return t;
    }

    private TextView pileCaption() {
        TextView t = Style.label(this, Style.bold, 10, Style.CREAM);
        t.setText("DRAW");
        t.setLetterSpacing(0.12f);
        t.setShadowLayer(dp(3), 0, dp(1), 0xCC000000);
        return t;
    }

    private View hidden(int id) {
        View v = new View(this);
        v.setId(id);
        v.setVisibility(View.GONE);
        return v;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void installGestures(View v, Runnable onSwipe, Runnable onTap) {
        GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                if (onTap != null) onTap.run();
                return onTap != null;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null) return false;
                if ((e2.getY() - e1.getY()) < -dp(28) && Math.abs(vy) >= Math.abs(vx)) {
                    onSwipe.run();
                    return true;
                }
                return false;
            }
        });
        v.setOnTouchListener((view, e) -> {
            gd.onTouchEvent(e);
            return true;
        });
    }

    // --- you-win / try-again: plate + Play Again ----------------------

    private void buildResultPlates() {
        screenYouWin = resultPlate(R.id.screen_you_win, R.drawable.bg_you_win, PA_WIN_BOX, true);
        screenTryAgain = resultPlate(R.id.screen_try_again, R.drawable.bg_try_again, PA_LOSE_BOX, false);
    }

    private PlateLayout resultPlate(int screenId, int plateId, float[] paBox, boolean isWin) {
        PlateLayout p = fullScreen(screenId);
        p.add(plate(plateId), 0f, 0f, 1f, 1f);

        if (isWin) {
            confetti = new ConfettiView(this);
            p.add(confetti, 0f, 0f, 1f, 1f);
        }

        View playAgain;
        Drawable art = null;
        try {
            art = getResources().getDrawable(R.drawable.btn_play_again, getTheme());
        } catch (RuntimeException loadError) {
            art = null;
        }
        if (art != null) {
            ImageButton pa = new ImageButton(this);
            pa.setScaleType(ImageView.ScaleType.FIT_CENTER);
            pa.setBackgroundColor(Color.TRANSPARENT);
            pa.setPadding(0, 0, 0, 0);
            pa.setImageDrawable(art);
            pa.setContentDescription("Play again");
            Style.pressable(pa);
            playAgain = pa;
        } else {
            playAgain = Style.candy(this, "PLAY AGAIN", Style.Candy.GOLD, 20);
        }
        playAgain.setId(R.id.btn_play_again);
        playAgain.setOnClickListener(v -> {
            sfx.play(Sfx.TAP);
            tapHaptic(v);
            showTitle(true);
        });
        p.add(playAgain, paBox[0], paBox[1], paBox[2], paBox[3]);

        TextView strip = Style.label(this, Style.ui, 15, Style.CREAM);
        strip.setBackground(Style.pill(this));
        strip.setPadding(dp(14), 0, dp(14), 0);
        strip.setMaxLines(1);
        strip.setAutoSizeTextTypeUniformWithConfiguration(9, 15, 1, TypedValue.COMPLEX_UNIT_SP);
        p.add(strip, 0.05f, 0.885f, 0.90f, 0.044f);
        if (isWin) resultStripWin = strip;
        else resultStripLose = strip;

        p.setVisibility(View.GONE);
        return p;
    }

    // --- overlays -----------------------------------------------------

    @SuppressLint("ClickableViewAccessibility")
    private void buildSortOverlay() {
        overlaySort = fullScreen(R.id.overlay_sort);
        overlaySort.add(plate(R.drawable.bg_sort), 0f, 0f, 1f, 1f);

        PlateLayout grid = new PlateLayout(this);
        grid.setTag("sort_grid");
        overlaySort.add(grid, 0f, 0f, 1f, 1f);

        Style.OutlineText title = Style.headline(this, "SORT YOUR HAND", 26);
        overlaySort.add(title, 0.05f, 0.045f, 0.90f, 0.06f);

        TextView hint = Style.label(this, Style.ui, 13, Style.CREAM);
        hint.setBackground(Style.pill(this));
        hint.setText("Tap two cards to swap  ·  swipe up when done");
        hint.setMaxLines(1);
        hint.setAutoSizeTextTypeUniformWithConfiguration(9, 13, 1, TypedValue.COMPLEX_UNIT_SP);
        hint.setPadding(dp(12), 0, dp(12), 0);
        overlaySort.add(hint, 0.06f, 0.905f, 0.88f, 0.040f);

        overlaySort.setOnTouchListener((v, e) -> {
            if (swipeUp.onTouchEvent(e)) closeSortOverlay();
            return true;
        });
        overlaySort.setVisibility(View.GONE);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void buildScoreOverlay() {
        overlayScores = fullScreen(R.id.overlay_scores);
        overlayScores.add(plate(R.drawable.bg_score_card), 0f, 0f, 1f, 1f);

        scoreGirl = sticky(R.id.score_girl);
        scoreBoy = sticky(R.id.score_boy);
        scoreCat = sticky(R.id.score_cat);
        scorePlayer = sticky(R.id.score_player);
        add(overlayScores, scoreGirl, SC_GIRL);
        add(overlayScores, scoreBoy, SC_BOY);
        add(overlayScores, scoreCat, SC_CAT);
        add(overlayScores, scorePlayer, SC_ME);

        labelScores = Style.label(this, Style.ui, 15, Style.CREAM);
        labelScores.setId(R.id.label_scores);
        labelScores.setBackground(Style.pill(this));
        labelScores.setMaxLines(1);
        labelScores.setAutoSizeTextTypeUniformWithConfiguration(9, 15, 1, TypedValue.COMPLEX_UNIT_SP);
        labelScores.setPadding(dp(14), 0, dp(14), 0);
        overlayScores.add(labelScores, 0.06f, 0.925f, 0.88f, 0.044f);

        overlayScores.setOnTouchListener((v, e) -> {
            if (swipeUp.onTouchEvent(e)) dismissScores();
            return true;
        });
        overlayScores.setVisibility(View.GONE);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void buildMeldOverlay() {
        overlayMelds = fullScreen(R.id.overlay_melds);
        View scrim = new View(this);
        scrim.setBackgroundColor(0xD0120818);
        overlayMelds.add(scrim, 0f, 0f, 1f, 1f);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(Style.panel(this));
        frame.setPadding(dp(14), dp(14), dp(14), dp(14));
        ScrollView scroll = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setTag("panel");
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(panel);
        frame.addView(scroll, match());
        frame.setTag("frame");
        overlayMelds.add(frame, 0.05f, 0.12f, 0.90f, 0.76f);

        overlayMelds.setOnTouchListener((v, e) -> {
            if (swipeUp.onTouchEvent(e)) closeMeldOverlay();
            return true;
        });
        overlayMelds.setVisibility(View.GONE);
    }

    private TextView sticky(int id) {
        TextView t = Style.label(this, Style.hand, 21, Style.INK);
        t.setId(id);
        t.setLineSpacing(0, 0.9f);
        t.setAutoSizeTextTypeUniformWithConfiguration(10, 21, 1, TypedValue.COMPLEX_UNIT_SP);
        return t;
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    // ------------------------------------------------------------------
    // Screen flow
    // ------------------------------------------------------------------

    private void showTitle(boolean animate) {
        cancelFlow();
        hideOverlays();
        if (confetti != null) confetti.stop();
        View from = screenTable.getVisibility() == View.VISIBLE ? screenTable
                : screenYouWin.getVisibility() == View.VISIBLE ? screenYouWin
                : screenTryAgain.getVisibility() == View.VISIBLE ? screenTryAgain : null;
        screenTable.setVisibility(View.GONE);
        screenYouWin.setVisibility(View.GONE);
        screenTryAgain.setVisibility(View.GONE);
        if (from != null && animate) {
            from.setVisibility(View.VISIBLE);
            crossfade(from, screenTitle, 380);
            sfx.play(Sfx.WHOOSH, 0.7f);
        } else {
            screenTitle.setAlpha(1f);
            screenTitle.setVisibility(View.VISIBLE);
        }
        for (int id : new int[]{R.id.btn_opp_1, R.id.btn_opp_2, R.id.btn_opp_3}) {
            View v = screenTitle.findViewById(id);
            if (v != null) {
                v.setScaleX(1f);
                v.setScaleY(1f);
                v.setAlpha(1f);
            }
        }
        updateMuteIcons();
        startTitleIdle();
    }

    private void crossfade(View out, View in, long ms) {
        in.setAlpha(0f);
        in.setVisibility(View.VISIBLE);
        in.animate().alpha(1f).setDuration(ms).setInterpolator(new DecelerateInterpolator()).start();
        out.animate().alpha(0f).setDuration(ms).withEndAction(() -> {
            out.setVisibility(View.GONE);
            out.setAlpha(1f);
        }).start();
    }

    private void onPickOpponents(View chosen, int opponents) {
        if (screenTitle.getVisibility() != View.VISIBLE || busy) return;
        busy = true;
        sfx.play(Sfx.TAP);
        tapHaptic(chosen);
        stopTitleIdle();
        chosen.animate().scaleX(1.12f).scaleY(1.12f).setDuration(160)
                .setInterpolator(new OvershootInterpolator(2f)).start();
        after(170, () -> {
            sfx.play(Sfx.WHOOSH, 0.8f);
            startGame(opponents);
        });
    }

    private void startGame(int opponents) {
        cancelFlow();
        engine.newGame(opponents);
        pendingDeal = true;
        tablePlate.setImageResource(tablePlate(opponents));
        selectedHandIndex = -1;
        lastLifted = -1;
        drawnHandIndex = -1;
        hideOverlays();
        screenYouWin.setVisibility(View.GONE);
        screenTryAgain.setVisibility(View.GONE);
        // Pre-hide the hand and discard so nothing pops before the deal.
        dealing = true;
        fanReveal = 0;
        hideAllDiscards = true;
        refreshTable();
        crossfade(screenTitle, screenTable, 420);
        after(300, this::dealRound);
    }

    private int tablePlate(int opponents) {
        switch (opponents) {
            case 1: return R.drawable.bg_table_1;
            case 2: return R.drawable.bg_table_2;
            default: return R.drawable.bg_table_3;
        }
    }

    private void showResult() {
        cancelFlow();
        hideOverlays();
        boolean humanWon = engine.winners().size() == 1 && engine.winners().get(0) == 0;
        PlateLayout target = humanWon ? screenYouWin : screenTryAgain;
        TextView strip = humanWon ? resultStripWin : resultStripLose;
        strip.setText(finalStandings());
        crossfade(screenTable, target, 500);

        View pa = target.findViewById(R.id.btn_play_again);
        pa.setVisibility(View.INVISIBLE);
        strip.setAlpha(0f);
        after(humanWon ? 900 : 1100, () -> {
            pa.setVisibility(View.VISIBLE);
            Style.popIn(pa, 0);
            strip.animate().alpha(1f).setDuration(400).start();
            after(500, () -> breathe(pa));
        });
        if (humanWon) {
            after(180, () -> sfx.play(Sfx.WIN));
            after(260, () -> confetti.burst(150));
        } else {
            after(260, () -> sfx.play(Sfx.LOSE));
        }
    }

    private String finalStandings() {
        List<Player> ps = new ArrayList<>(engine.players());
        Collections.sort(ps, (a, b) -> Integer.compare(a.cumulativeScore, b.cumulativeScore));
        StringBuilder sb = new StringBuilder();
        for (Player p : ps) {
            if (sb.length() > 0) sb.append("   ·   ");
            sb.append(p.name).append("  ").append(p.cumulativeScore);
        }
        return sb.toString();
    }

    private void breathe(View v) {
        ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.05f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.05f, 1f));
        a.setDuration(1600);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.start();
        final int token = seq;
        // stop when the flow moves on
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (token != seq || v.getVisibility() != View.VISIBLE
                        || ((View) v.getParent()).getVisibility() != View.VISIBLE) {
                    a.cancel();
                    v.setScaleX(1f);
                    v.setScaleY(1f);
                } else {
                    handler.postDelayed(this, 500);
                }
            }
        }, 500);
    }

    private void hideOverlays() {
        overlayScores.setVisibility(View.GONE);
        overlaySort.setVisibility(View.GONE);
        overlayMelds.setVisibility(View.GONE);
        sortSelected = -1;
        roundSummaryMode = false;
    }

    // ------------------------------------------------------------------
    // Round opening: banner, shuffle, deal, first discard
    // ------------------------------------------------------------------

    private void dealRound() {
        pendingDeal = false;
        busy = true;
        dealing = true;
        fanReveal = 0;
        hideAllDiscards = true;
        hideTop = 0;
        selectedHandIndex = -1;
        lastLifted = -1;
        drawnHandIndex = -1;
        spotSeat = -1;
        statusOverride = engine.isTiebreak() ? "Tiebreak! Lowest round score wins" : "Shuffling…";
        turnGlow.setSpot(-1);
        refreshTable();

        if (engine.isTiebreak()) {
            showBanner("TIEBREAK", "6 cards  ·  6s & Jokers are wild");
        } else {
            showBanner("ROUND " + engine.roundNumber(),
                    wildPlural() + " & Jokers are wild");
        }
        sfx.play(Sfx.ROUND_START);

        after(Pace.BANNER_HOLD, () -> {
            hideBanner();
            sfx.play(Sfx.SHUFFLE);
            shuffleWiggle();
            statusOverride = "Dealing…";
            refreshStatus();
        });
        after(Pace.BANNER_HOLD + Pace.SHUFFLE, this::dealCards);
    }

    private String wildPlural() {
        String w = engine.wildLabel();
        return w + "s";
    }

    private void shuffleWiggle() {
        ObjectAnimator a = ObjectAnimator.ofFloat(drawPile, View.ROTATION, 0f, -4f, 4f, -3f, 3f, 0f);
        a.setDuration(Pace.SHUFFLE);
        a.start();
    }

    private void dealCards() {
        List<Integer> active = new ArrayList<>(engine.activePlayers());
        int start = Math.max(0, active.indexOf(engine.currentIndex()));
        List<int[]> order = new ArrayList<>();   // {seat, handIndex}
        int dealt = engine.dealtCount();
        for (int i = 0; i < dealt; i++) {
            for (int k = 0; k < active.size(); k++) {
                int seat = active.get((start + k) % active.size());
                order.add(new int[]{seat, i});
            }
        }
        long gap = Math.max(Pace.DEAL_GAP_MIN, Math.min(Pace.DEAL_GAP_MAX,
                Pace.DEAL_TOTAL / Math.max(1, order.size())));
        for (int j = 0; j < order.size(); j++) {
            final int[] step = order.get(j);
            after(j * gap, () -> dealOne(step[0], step[1]));
        }
        long done = (order.size() - 1) * gap + Pace.DEAL_FLIGHT + 120;
        after(done, this::flipFirstDiscard);
    }

    private void dealOne(int seat, int handIndex) {
        RectF from = rectOf(drawPile);
        sfxAt(Sfx.DEAL, Pace.DEAL_FLIGHT - Pace.DEAL_LEAD, 0.85f);
        if (seat == 0) {
            if (handIndex >= fanViews.size()) return;
            View target = fanViews.get(handIndex);
            RectF to = rectOf(target);
            Card c = engine.handOf(0).get(handIndex);
            fly(cards.back(), from, to, Pace.DEAL_FLIGHT, 0f, target.getRotation(), 0.18f,
                    cards.face(c, engine.wildRank(), (int) to.height()), 1f, () -> {
                        fanReveal = Math.max(fanReveal, handIndex + 1);
                        target.setAlpha(1f);
                    });
        } else {
            RectF to = seatRect(seat);
            fly(cards.back(), from, to, Pace.DEAL_FLIGHT, 0f, rnd.nextFloat() * 20f - 10f, 0.12f,
                    null, 0f, null);
        }
    }

    private void flipFirstDiscard() {
        Card top = engine.topDiscard();
        if (top == null) {
            finishDeal();
            return;
        }
        RectF from = rectOf(drawPile);
        RectF to = rectOf(discardPile);
        sfxAt(Sfx.PLACE, Pace.FLIP_DISCARD - 40, 1f);
        fly(cards.back(), from, to, Pace.FLIP_DISCARD, 0f, restRotation(top), 0.35f,
                cards.face(top, engine.wildRank(), (int) to.height()), 1f, this::finishDeal);
    }

    private void finishDeal() {
        dealing = false;
        fanReveal = Integer.MAX_VALUE;
        hideAllDiscards = false;
        statusOverride = null;
        refreshTable();
        after(260, () -> continueFlow(true));
    }

    private void showBanner(String title, String sub) {
        bannerTitle.setText(title);
        bannerTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, title.length() > 9 ? 36 : 50);
        bannerSub.setText(sub);
        banner.animate().cancel();
        banner.setVisibility(View.VISIBLE);
        banner.setAlpha(0f);
        banner.setScaleX(0.7f);
        banner.setScaleY(0.7f);
        banner.setTranslationY(0f);
        banner.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420)
                .setInterpolator(new OvershootInterpolator(1.8f)).start();
    }

    private void hideBanner() {
        banner.animate().cancel();
        banner.animate().alpha(0f).translationY(-dp(24)).setDuration(260)
                .setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> banner.setVisibility(View.GONE)).start();
    }

    // ------------------------------------------------------------------
    // Turn flow
    // ------------------------------------------------------------------

    /** Decide what happens next after any action has fully landed. */
    private void continueFlow(boolean announce) {
        busy = false;
        statusOverride = null;
        if (screenTable.getVisibility() != View.VISIBLE) return;
        if (engine.isGameOver()) {
            showResult();
            return;
        }
        GameEngine.Phase ph = engine.phase();
        if (ph == GameEngine.Phase.ROUND_OVER) {
            roundEndSequence();
            return;
        }
        if (engine.currentIndex() == 0) {
            beginHumanTurn(announce);
        } else if (engine.aiShouldAct()) {
            runAiTurn();
        } else {
            refreshTable();
        }
    }

    private void beginHumanTurn(boolean announce) {
        spotSeat = -1;
        turnGlow.setSpot(-1);
        refreshTable();
        if (announce && engine.phase() == GameEngine.Phase.WAIT_DRAW) {
            sfx.play(Sfx.YOUR_TURN);
            pulse(labelStatus);
        }
        scheduleIdleHint();
    }

    private void scheduleIdleHint() {
        handler.removeCallbacks(idleHint);
        handler.postDelayed(idleHint, Pace.IDLE_HINT);
    }

    private void playIdleHint() {
        if (busy || screenTable.getVisibility() != View.VISIBLE || engine.currentIndex() != 0
                || overlayScores.getVisibility() == View.VISIBLE
                || overlaySort.getVisibility() == View.VISIBLE) return;
        GameEngine.Phase ph = engine.phase();
        if (ph == GameEngine.Phase.WAIT_DRAW) {
            bounce(drawPile, 0);
            bounce(discardPile, 120);
        } else if (ph == GameEngine.Phase.INSERT_PENDING && raisedView != null) {
            bounce(raisedView, 0);
        } else if (ph == GameEngine.Phase.WAIT_DISCARD && selectedHandIndex >= 0) {
            bounce(discardPile, 0);
        } else {
            return;
        }
        handler.postDelayed(idleHint, Pace.IDLE_HINT);
    }

    // --- opponents ----------------------------------------------------

    private void runAiTurn() {
        final int seat = engine.currentIndex();
        busy = true;
        spotSeat = seat;
        turnGlow.setSpot(seat);
        final Player pl = engine.player(seat);
        statusOverride = pl.name + "'s turn";
        refreshTable();
        sfx.play(Sfx.OPP_TURN);

        after(Pace.AI_SPOTLIGHT, () -> {
            Card topBefore = engine.topDiscard();
            int drawBefore = engine.drawPile().size();
            boolean laidBefore = pl.laidDownThisRound;
            int outBefore = engine.wentOutIndex();

            engine.playAiTurnFor(seat);
            if (engine.currentIndex() == seat && engine.phase() != GameEngine.Phase.ROUND_OVER
                    && engine.topDiscard() == topBefore) {
                // The engine declined the move; never loop on it.
                busy = false;
                statusOverride = null;
                turnGlow.setSpot(-1);
                refreshTable();
                return;
            }

            boolean wentOut = outBefore == -1 && engine.wentOutIndex() == seat;
            boolean laid = !wentOut && !laidBefore && pl.laidDownThisRound && !pl.laidMelds.isEmpty();
            int drawAfter = engine.drawPile().size();
            boolean tookDiscard = topBefore != null
                    && ((drawBefore > 0 && drawAfter == drawBefore)
                    || containsUid(pl.hand, topBefore.uid) || meldsContain(pl.laidMelds, topBefore.uid));

            // Hold the new discard back until its card actually lands.
            hideTop = 1;
            statusOverride = tookDiscard ? pl.name + " takes the discard" : pl.name + " draws";
            refreshTable();

            RectF from = tookDiscard ? rectOf(discardPile) : rectOf(drawPile);
            RectF to = seatRect(seat);
            View ghost = tookDiscard
                    ? cards.face(topBefore, engine.wildRank(), (int) to.height())
                    : cards.back();
            sfx.play(Sfx.DRAW, 0.9f);
            fly(ghost, from, to, Pace.AI_DRAW_FLIGHT, tookDiscard ? restRotation(topBefore) : 0f,
                    rnd.nextFloat() * 24f - 12f, 0.16f, null, 0f, () -> {
                        if (wentOut) {
                            statusOverride = pl.name + " goes out!";
                            refreshStatus();
                            showBanner(pl.name.toUpperCase() + " WENT OUT!", "Everyone gets one final turn");
                            sfx.play(Sfx.GO_OUT);
                            commitHaptic(screenTable);
                            after(Pace.OUT_BANNER, () -> {
                                hideBanner();
                                aiDiscardStep(seat);
                            });
                        } else if (laid) {
                            statusOverride = pl.name + " lays " + pl.laidMelds.size()
                                    + (pl.laidMelds.size() == 1 ? " meld" : " melds");
                            refreshStatus();
                            sfx.play(Sfx.MELD, 0.8f);
                            after(Pace.MELD_BEAT, () -> aiDiscardStep(seat));
                        } else {
                            statusOverride = pl.name + " is thinking…";
                            refreshStatus();
                            long think = Pace.AI_THINK_MIN
                                    + (long) (rnd.nextFloat() * (Pace.AI_THINK_MAX - Pace.AI_THINK_MIN));
                            after(think, () -> aiDiscardStep(seat));
                        }
                    });
        });
    }

    private void aiDiscardStep(int seat) {
        Card d = engine.topDiscard();
        if (d == null) {
            hideTop = 0;
            after(Pace.AI_SETTLE, () -> continueFlow(true));
            return;
        }
        Player pl = engine.player(seat);
        statusOverride = pl.name + " discards";
        refreshStatus();
        RectF from = seatRect(seat);
        RectF to = rectOf(discardPile);
        sfxAt(Sfx.DISCARD, Pace.AI_DISCARD_FLIGHT - Pace.DISCARD_LEAD, 0.9f);
        fly(cards.face(d, engine.wildRank(), (int) to.height()), from, to, Pace.AI_DISCARD_FLIGHT,
                rnd.nextFloat() * 40f - 20f, restRotation(d), 0.22f, null, 1f, () -> {
                    hideTop = 0;
                    refreshTable();
                    thump(discardPile);
                    after(Pace.AI_SETTLE, () -> continueFlow(true));
                });
    }

    private static boolean containsUid(List<Card> hand, int uid) {
        for (Card c : hand) if (c.uid == uid) return true;
        return false;
    }

    private static boolean meldsContain(List<Meld> melds, int uid) {
        for (Meld m : melds) if (containsUid(m.cards, uid)) return true;
        return false;
    }

    // --- round end ----------------------------------------------------

    private void roundEndSequence() {
        busy = true;
        spotSeat = -1;
        turnGlow.setSpot(-1);
        statusOverride = engine.isTiebreak() ? "Tiebreak over" : "Round over";
        refreshTable();
        after(Pace.ROUND_END_PAUSE, () -> {
            sfx.play(Sfx.ROUND_END);
            showScoreOverlay(true);
        });
    }

    // ------------------------------------------------------------------
    // Rendering
    // ------------------------------------------------------------------

    private void refreshTable() {
        String round = engine.isTiebreak() ? "TIEBREAK"
                : "Round " + engine.roundNumber() + " of " + GameEngine.TOTAL_ROUNDS;
        labelRound.setText(round);
        labelWild.setText("Wild: " + wildPlural() + " + Jokers");
        refreshStatus();

        drawCaption.setText("DRAW  ·  " + engine.drawPile().size());
        updateDiscardPile();
        cloudScore.setText(String.valueOf(engine.human().cumulativeScore));

        renderMelds(meldPlayer, engine.meldsFor(0));
        renderFan();
        updateButtons();
        turnGlow.invalidate();
    }

    private void refreshStatus() {
        String s = statusOverride != null ? statusOverride : turnLine();
        if (!s.contentEquals(labelStatus.getText())) {
            labelStatus.setText(s);
            labelStatus.setAlpha(0.35f);
            labelStatus.animate().alpha(1f).setDuration(180).start();
        }
        boolean mine = statusOverride == null && engine.currentIndex() == 0
                && engine.phase() != GameEngine.Phase.ROUND_OVER;
        labelStatus.setTextColor(mine ? Style.GOLD_LIGHT : Style.CREAM);
    }

    /** Friendly status copy for the human's turn. */
    private String turnLine() {
        GameEngine.Phase ph = engine.phase();
        if (ph == GameEngine.Phase.ROUND_OVER) return "Round over";
        if (ph == GameEngine.Phase.GAME_OVER) return "Game over";
        int seat = engine.currentIndex();
        if (seat != 0) return engine.player(seat).name + "'s turn";
        boolean fin = engine.isFinalTurn(0);
        switch (ph) {
            case WAIT_DRAW:
                return fin ? "Final turn!  Draw a card" : "Your turn  ·  draw a card";
            case INSERT_PENDING:
                if (engine.canDeclareOut(0)) return "You can go out!  Tap DECLARE OUT";
                return "Tap a card to slot it in front";
            case WAIT_DISCARD:
                if (engine.canDeclareOut(0)) return "You can go out!  Tap DECLARE OUT";
                if (fin && !engine.human().laidDownThisRound) return "Lay your melds, then discard";
                return selectedHandIndex < 0 ? "Pick a card to discard" : "Tap the discard pile";
            default:
                return "Your turn";
        }
    }

    private void updateDiscardPile() {
        discardPile.removeAllViews();
        List<Card> pile = engine.discardPile();
        int visibleTop = pile.size() - 1 - hideTop;
        if (hideAllDiscards || visibleTop < 0) {
            View slot = new View(this);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(0x22000000);
            g.setStroke(dp(2), 0x55FFF4D6);
            slot.setBackground(g);
            discardPile.addView(slot, match());
            return;
        }
        int h = discardPile.getHeight() > 0 ? discardPile.getHeight()
                : Math.round(getResources().getDisplayMetrics().heightPixels * DISC_BOX[3]);
        if (visibleTop - 1 >= 0) {
            Card under = pile.get(visibleTop - 1);
            View u = cards.face(under, engine.wildRank(), h);
            u.setRotation(restRotation(under));
            discardPile.addView(u, match());
        }
        Card top = pile.get(visibleTop);
        View t = cards.face(top, engine.wildRank(), h);
        t.setRotation(restRotation(top));
        t.setElevation(dp(3));
        discardPile.addView(t, match());
    }

    /** Each card rests on the pile at its own slight angle, like a real throw. */
    private static float restRotation(Card c) {
        int r = (c.uid * 7919) % 13;
        return (r < 0 ? r + 13 : r) - 6;
    }

    private void renderMelds(LinearLayout tray, List<Meld> melds) {
        tray.removeAllViews();
        for (Meld m : melds) {
            TextView tv = Style.label(this, Style.bold, 11, Style.GOLD_LIGHT);
            tv.setText(meldName(m));
            tv.setBackground(Style.chip(this, 0xE0221330));
            tv.setPadding(dp(8), 0, dp(8), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.leftMargin = dp(3);
            lp.rightMargin = dp(3);
            tray.addView(tv, lp);
        }
    }

    private String meldName(Meld m) {
        int wild = engine.wildRank();
        if (m.type == Meld.Type.BOOK) {
            for (Card c : m.cards) {
                if (!c.isWild(wild)) return "BOOK  " + c.rankLabel() + "s";
            }
            return "BOOK";
        }
        for (Card c : m.cards) {
            if (!c.isWild(wild)) return "RUN  " + CardFactory.suitSymbol(c.suit);
        }
        return "RUN";
    }

    private void renderFan() {
        fanTop.removeAllViews();
        fanBottom.removeAllViews();
        fanViews.clear();
        View stale = fanBox.findViewWithTag("raised_card");
        if (stale != null) fanBox.removeView(stale);
        raisedView = null;

        List<Card> hand = engine.handOf(0);
        boolean insertPending = engine.phase() == GameEngine.Phase.INSERT_PENDING
                && engine.currentIndex() == 0
                && drawnHandIndex >= 0 && drawnHandIndex < hand.size();

        List<Card> parked = new ArrayList<>();
        Card raised = null;
        for (int i = 0; i < hand.size(); i++) {
            if (insertPending && i == drawnHandIndex) raised = hand.get(i);
            else parked.add(hand.get(i));
        }
        for (int i = 0; i < hand.size(); i++) fanViews.add(null);
        int topCount = Math.min(7, parked.size());
        addFanCards(fanTop, parked, 0, topCount, 0);
        if (parked.size() > 7) addFanCards(fanBottom, parked, 7, parked.size(), 7);

        if (raised != null) addRaisedCard(raised, drawnHandIndex);
        lastLifted = selectedHandIndex;
    }

    private void addRaisedCard(Card card, int handIndex) {
        int cardH = fanRowHeight();
        int cardW = Math.max(dp(1), (int) (cardH * 0.72f));

        FrameLayout holder = new FrameLayout(this);
        holder.setTag("raised_card");
        holder.setClipChildren(false);
        View cv = cards.face(card, engine.wildRank(), cardH);
        cv.setElevation(dp(8));
        cv.setOnClickListener(v -> onHandCardTapped(handIndex));
        holder.addView(cv, match());
        if (raisedHidden) holder.setAlpha(0f);

        int fanWidth = fanBox.getWidth();
        int fanHeight = fanBox.getHeight();
        if (fanWidth <= 0) fanWidth = Math.round(getResources().getDisplayMetrics().widthPixels * FAN_BOX[2]);
        if (fanHeight <= 0) fanHeight = Math.round(getResources().getDisplayMetrics().heightPixels * FAN_BOX[3]);
        float fw = (float) cardW / fanWidth;
        float fh = (float) cardH / fanHeight;
        fanBox.add(holder, 0.5f - fw / 2f, -0.08f, fw, fh);
        raisedView = holder;
        if (handIndex < fanViews.size()) fanViews.set(handIndex, holder);
    }

    private void addFanCards(LinearLayout row, List<Card> hand, int from, int to, int offset) {
        int cardH = fanRowHeight();
        int cardW = (int) (cardH * 0.72f);
        int avail = Math.max(cardW, rowWidth());
        int n = to - from;
        int shift = cardW;
        if (n > 1) shift = Math.min((int) (cardW * 0.74f), Math.max(1, (avail - cardW) / (n - 1)));
        float half = Math.max(1f, (n - 1) / 2f);
        float lift = dp(16);
        for (int i = from; i < to; i++) {
            final int idx = offset + (i - from);
            Card c = hand.get(i);
            View cv = cards.face(c, engine.wildRank(), cardH);
            cv.setOnClickListener(v -> onHandCardTapped(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cardW, cardH);
            if (i > from) lp.leftMargin = -(cardW - shift);
            row.addView(cv, lp);

            // Shallow bow: centre higher than the wings.
            float off = n > 1 ? ((i - from) - (n - 1) / 2f) / half : 0f;
            float base = off * off * dp(7);
            cv.setRotation(off * 5f);
            if (idx == selectedHandIndex) {
                if (lastLifted != idx) {
                    cv.setTranslationY(base);
                    cv.animate().translationY(base - lift).setDuration(200)
                            .setInterpolator(new OvershootInterpolator(2.4f)).start();
                } else {
                    cv.setTranslationY(base - lift);
                }
                cv.setElevation(dp(6));
            } else if (idx == lastLifted) {
                cv.setTranslationY(base - lift);
                cv.animate().translationY(base).setDuration(170)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else {
                cv.setTranslationY(base);
            }
            if (dealing && idx >= fanReveal) cv.setAlpha(0f);
            int handIdx = mapParkedToHand(idx);
            if (handIdx >= 0 && handIdx < fanViews.size()) fanViews.set(handIdx, cv);
        }
    }

    /** Parked index -> hand index (the raised card is excluded from the parked list). */
    private int mapParkedToHand(int parkedIdx) {
        boolean insertPending = engine.phase() == GameEngine.Phase.INSERT_PENDING
                && drawnHandIndex >= 0;
        if (insertPending && parkedIdx >= drawnHandIndex) return parkedIdx + 1;
        return parkedIdx;
    }

    private int fanRowHeight() {
        return Math.max(dp(40), (int) (getResources().getDisplayMetrics().heightPixels
                * FAN_BOX[3] * 0.46f));
    }

    private int rowWidth() {
        return (int) (getResources().getDisplayMetrics().widthPixels * FAN_BOX[2]);
    }

    private void updateButtons() {
        boolean mine = engine.currentIndex() == 0 && !busy && !dealing;
        GameEngine.Phase ph = engine.phase();
        boolean canOut = mine && engine.canDeclareOut(0);
        boolean canLay = mine && engine.isFinalTurn(0) && ph == GameEngine.Phase.WAIT_DISCARD
                && !engine.human().laidDownThisRound && engine.handOf(0).size() >= 2;
        boolean insertPending = mine && ph == GameEngine.Phase.INSERT_PENDING && !raisedHidden;
        setButton(btnDeclareOut, canOut);
        setButton(btnLayMelds, canLay);
        setButton(btnParkEnd, insertPending);
        if (canOut) glowButton(btnDeclareOut);
    }

    private void setButton(View b, boolean show) {
        boolean shown = b.getVisibility() == View.VISIBLE;
        if (show && !shown) {
            b.setVisibility(View.VISIBLE);
            Style.popIn(b, 0);
        } else if (!show && shown) {
            b.animate().cancel();
            b.setVisibility(View.GONE);
        }
    }

    private void glowButton(View b) {
        if (b.getTag() instanceof Animator && ((Animator) b.getTag()).isRunning()) return;
        ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(b,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.07f, 1f));
        a.setDuration(900);
        a.setStartDelay(350);
        a.setRepeatCount(5);
        b.setTag(a);
        a.start();
    }

    // ------------------------------------------------------------------
    // Interaction
    // ------------------------------------------------------------------

    private boolean myTurnReady() {
        return !busy && !dealing && engine.currentIndex() == 0
                && screenTable.getVisibility() == View.VISIBLE;
    }

    private void onHandCardTapped(int index) {
        if (!myTurnReady()) return;
        scheduleIdleHint();
        GameEngine.Phase ph = engine.phase();

        if (ph == GameEngine.Phase.INSERT_PENDING) {
            parkDrawn(index == drawnHandIndex ? -1 : index);
            return;
        }
        if (ph != GameEngine.Phase.WAIT_DISCARD) {
            if (ph == GameEngine.Phase.WAIT_DRAW) nudge("Draw first  ·  tap the deck or the discard");
            return;
        }
        boolean deselect = selectedHandIndex == index;
        selectedHandIndex = deselect ? -1 : index;
        sfx.play(deselect ? Sfx.DESELECT : Sfx.SELECT);
        tapHaptic(screenTable);
        refreshTable();
    }

    private void onEmptyFanTapped() {
        if (!myTurnReady()) return;
        if (engine.phase() == GameEngine.Phase.WAIT_DISCARD && selectedHandIndex >= 0) {
            selectedHandIndex = -1;
            sfx.play(Sfx.DESELECT);
            tapHaptic(screenTable);
            refreshTable();
        }
    }

    /** Slot the raised card in front of parked card {@code beforeIndex} (or -1 = end). */
    private void parkDrawn(int beforeIndex) {
        if (engine.phase() != GameEngine.Phase.INSERT_PENDING) return;
        RectF from = raisedView != null ? rectOf(raisedView) : rectOf(fanBox);
        Card moving = engine.pendingCard();
        if (moving == null) return;
        int finalIndex;
        if (beforeIndex < 0) {
            engine.parkPendingAtEnd(0);
            finalIndex = engine.handOf(0).size() - 1;
        } else {
            engine.parkPending(0, beforeIndex);
            finalIndex = beforeIndex;
        }
        drawnHandIndex = -1;
        selectedHandIndex = -1;
        busy = true;
        refreshTable();
        tapHaptic(screenTable);
        final int fi = finalIndex;
        afterLayout(() -> {
            View target = fi < fanViews.size() ? fanViews.get(fi) : null;
            if (target == null) {
                busy = false;
                refreshTable();
                return;
            }
            target.setAlpha(0f);
            RectF to = rectOf(target);
            sfxAt(Sfx.PLACE, Pace.PARK_FLIGHT - 40, 0.9f);
            fly(cards.face(moving, engine.wildRank(), (int) to.height()), from, to, Pace.PARK_FLIGHT,
                    0f, target.getRotation(), 0.1f, null, 1f, () -> {
                        target.setAlpha(1f);
                        busy = false;
                        refreshTable();
                        scheduleIdleHint();
                    });
        });
    }

    private void onDrawTapped() {
        if (!myTurnReady()) return;
        scheduleIdleHint();
        if (engine.phase() != GameEngine.Phase.WAIT_DRAW) {
            nudge(engine.phase() == GameEngine.Phase.INSERT_PENDING
                    ? "Slot the new card into your hand first" : "You already drew  ·  now discard");
            return;
        }
        RectF from = rectOf(drawPile);
        if (engine.drawHuman(0, false) == null) return;
        humanDrawFlight(from, null);
    }

    private void onDiscardTapped() {
        if (!myTurnReady()) return;
        scheduleIdleHint();
        GameEngine.Phase ph = engine.phase();
        if (ph == GameEngine.Phase.WAIT_DRAW) {
            Card top = engine.topDiscard();
            if (top == null) return;
            RectF from = rectOf(discardPile);
            float rot = restRotation(top);
            if (engine.drawHuman(0, true) == null) return;
            humanDrawFlight(from, rot);
            return;
        }
        if (ph == GameEngine.Phase.INSERT_PENDING) {
            nudge("Slot the new card into your hand first");
            return;
        }
        if (ph == GameEngine.Phase.WAIT_DISCARD) {
            if (selectedHandIndex < 0) {
                nudge("Pick a card first, then tap here");
                if (!fanViews.isEmpty()) {
                    for (View v : fanViews) if (v != null) bounce(v, 0);
                }
                return;
            }
            humanCommit(engine.canDeclareOut(0));
        }
    }

    /** A drawn card flies from the pile into the raised slot above your fan. */
    private void humanDrawFlight(RectF from, Float discardRot) {
        boolean fromDiscard = discardRot != null;
        Card drawn = engine.pendingCard();
        drawnHandIndex = engine.pendingHandIndex();
        selectedHandIndex = -1;
        busy = true;
        raisedHidden = true;
        sfx.play(Sfx.DRAW);
        tapHaptic(screenTable);
        refreshTable();
        afterLayout(() -> {
            if (raisedView == null || drawn == null) {
                raisedHidden = false;
                busy = false;
                refreshTable();
                return;
            }
            RectF to = rectOf(raisedView);
            View face = cards.face(drawn, engine.wildRank(), (int) to.height());
            View start = fromDiscard ? face : cards.back();
            fly(start, from, to, Pace.DRAW_FLIGHT, fromDiscard ? discardRot : 0f, 0f, 0.2f,
                    fromDiscard ? null : face, 1f, () -> {
                        raisedHidden = false;
                        busy = false;
                        refreshTable();
                        if (raisedView != null) thump(raisedView);
                        if (engine.canDeclareOut(0)) sfx.play(Sfx.MELD, 0.5f);
                        scheduleIdleHint();
                    });
        });
    }

    /** Discard the locked card (or go out, letting the validator choose the leftover). */
    private void humanCommit(boolean goingOut) {
        Map<Integer, RectF> rects = new HashMap<>();
        List<Card> hand = engine.handOf(0);
        for (int i = 0; i < hand.size() && i < fanViews.size(); i++) {
            View v = fanViews.get(i);
            if (v != null) rects.put(hand.get(i).uid, rectOf(v));
        }
        float startRot = 0f;
        if (selectedHandIndex >= 0 && selectedHandIndex < fanViews.size()
                && fanViews.get(selectedHandIndex) != null) {
            startRot = fanViews.get(selectedHandIndex).getRotation();
        }
        boolean ok;
        if (goingOut) ok = engine.declareOut(0);
        else ok = engine.discardCard(0, selectedHandIndex);
        if (!ok) {
            nudge("That move isn't allowed right now");
            return;
        }
        selectedHandIndex = -1;
        drawnHandIndex = -1;
        busy = true;
        hideTop = 1;
        Card d = engine.topDiscard();
        refreshTable();
        if (d == null) {
            hideTop = 0;
            continueFlow(true);
            return;
        }
        RectF from = rects.containsKey(d.uid) ? rects.get(d.uid) : rectOf(fanBox);
        RectF to = rectOf(discardPile);
        sfxAt(Sfx.DISCARD, Pace.DISCARD_FLIGHT - Pace.DISCARD_LEAD, 1f);
        fly(cards.face(d, engine.wildRank(), (int) to.height()), from, to, Pace.DISCARD_FLIGHT,
                startRot, restRotation(d), 0.28f, null, 1f, () -> {
                    hideTop = 0;
                    refreshTable();
                    thump(discardPile);
                    commitHaptic(screenTable);
                    if (goingOut) {
                        showBanner("YOU WENT OUT!", "Everyone else gets one final turn");
                        sfx.play(Sfx.GO_OUT);
                        after(Pace.OUT_BANNER, () -> {
                            hideBanner();
                            after(200, () -> continueFlow(true));
                        });
                    } else {
                        after(Pace.AFTER_YOUR_DISCARD, () -> continueFlow(true));
                    }
                });
    }

    private void onParkEnd() {
        if (!myTurnReady()) return;
        sfx.play(Sfx.TAP, 0.7f);
        parkDrawn(-1);
    }

    private void onDeclareOut() {
        if (!myTurnReady()) return;
        if (engine.canDeclareOut(0)) {
            drawnHandIndex = engine.phase() == GameEngine.Phase.INSERT_PENDING ? drawnHandIndex : -1;
            humanCommit(true);
        }
    }

    private void onLayMelds() {
        if (!myTurnReady()) return;
        if (engine.phase() != GameEngine.Phase.WAIT_DISCARD || !engine.isFinalTurn(0)) return;
        if (engine.layMelds(0)) {
            selectedHandIndex = -1;
            sfx.play(Sfx.MELD);
            commitHaptic(screenTable);
            refreshTable();
            showMeldOverlay();
        } else {
            nudge("No melds to lay");
        }
    }

    private void onOwnBubbleTapped() {
        if (dealing || overlayScores.getVisibility() == View.VISIBLE) return;
        if (busy && engine.currentIndex() == 0) return;
        sfx.play(Sfx.TAP);
        tapHaptic(cloudPlayer);
        showScoreOverlay(false);
    }

    private void nudge(String msg) {
        statusOverride = msg;
        refreshStatus();
        Style.shake(labelStatus);
        sfx.play(Sfx.NUDGE);
        tapHaptic(screenTable);
        final String shown = msg;
        handler.postDelayed(() -> {
            if (shown.equals(statusOverride) && !busy) {
                statusOverride = null;
                refreshStatus();
            }
        }, 2200);
    }

    // ------------------------------------------------------------------
    // Card flight
    // ------------------------------------------------------------------

    /** Bounds of a view in fxLayer coordinates (translation-aware, rotation-free). */
    private RectF rectOf(View v) {
        int[] f = new int[2];
        fxLayer.getLocationOnScreen(f);
        View parent = (View) v.getParent();
        int[] p = new int[2];
        if (parent != null) parent.getLocationOnScreen(p);
        float x = p[0] - f[0] + v.getLeft() + v.getTranslationX();
        float y = p[1] - f[1] + v.getTop() + v.getTranslationY();
        return new RectF(x, y, x + v.getWidth(), y + v.getHeight());
    }

    private float[][] seats() {
        int o = engine.opponentCount();
        return o == 1 ? SEATS_1 : o == 2 ? SEATS_2 : SEATS_3;
    }

    /** Where an opponent's cards come and go: just in front of the character. */
    private RectF seatRect(int seat) {
        float[][] s = seats();
        int i = Math.max(0, Math.min(s.length - 1, seat - 1));
        float w = fxLayer.getWidth(), h = fxLayer.getHeight();
        float cw = w * 0.10f, ch = cw * 1.39f;
        float cx = w * s[i][0], cy = h * (s[i][1] + 0.085f);
        return new RectF(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2);
    }

    /**
     * Fly {@code content} from one rect to another along a gentle arc, scaling
     * between their sizes. If {@code flipTo} is given the card turns over at the
     * midpoint. {@code endAlpha} < 1 fades it out as it arrives (into a hand).
     */
    private void fly(View content, RectF from, RectF to, long dur, float rot0, float rot1,
                     float arc, View flipTo, float endAlpha, Runnable onEnd) {
        final int token = seq;
        int w = Math.max(1, Math.round(to.width()));
        int h = Math.max(1, Math.round(to.height()));
        FrameLayout g = new FrameLayout(this);
        g.setClipChildren(false);
        content.setElevation(dp(10));
        g.addView(content, match());
        if (flipTo != null) {
            flipTo.setElevation(dp(10));
            flipTo.setVisibility(View.INVISIBLE);
            g.addView(flipTo, match());
        }
        fxLayer.addView(g, new FrameLayout.LayoutParams(w, h));
        g.setPivotX(w / 2f);
        g.setPivotY(h / 2f);

        final float sx0 = from.width() / w, sy0 = from.height() / h;
        final float x0 = from.centerX(), y0 = from.centerY(), x1 = to.centerX(), y1 = to.centerY();
        final float dist = (float) Math.hypot(x1 - x0, y1 - y0);
        final float cx = (x0 + x1) / 2f, cy = (y0 + y1) / 2f - arc * dist;
        final boolean[] flipped = {false};

        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(dur);
        a.setInterpolator(EASE);
        a.addUpdateListener(an -> {
            float t = (float) an.getAnimatedValue();
            float q = 1f - t;
            float x = q * q * x0 + 2 * q * t * cx + t * t * x1;
            float y = q * q * y0 + 2 * q * t * cy + t * t * y1;
            float lift = 1f + 0.08f * (float) Math.sin(Math.PI * t);
            float sx = (sx0 + (1f - sx0) * t) * lift;
            float sy = (sy0 + (1f - sy0) * t) * lift;
            if (flipTo != null) {
                float f = Math.abs((float) Math.cos(Math.PI * t));
                sx *= Math.max(0.03f, f);
                if (t >= 0.5f && !flipped[0]) {
                    flipped[0] = true;
                    content.setVisibility(View.INVISIBLE);
                    flipTo.setVisibility(View.VISIBLE);
                }
            }
            g.setScaleX(sx);
            g.setScaleY(sy);
            g.setTranslationX(x - w / 2f);
            g.setTranslationY(y - h / 2f);
            g.setRotation(rot0 + (rot1 - rot0) * t);
            if (endAlpha < 1f) {
                float k = Math.max(0f, (t - 0.55f) / 0.45f);
                g.setAlpha(1f - (1f - endAlpha) * k);
            }
        });
        a.addListener(new AnimatorListenerAdapter() {
            boolean cancelled;

            @Override
            public void onAnimationCancel(Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                fxLayer.removeView(g);
                if (!cancelled && token == seq && onEnd != null) onEnd.run();
            }
        });
        g.setTag(a);
        a.start();
    }

    private void sfxAt(int sound, long delay, float vol) {
        if (delay <= 0) sfx.play(sound, vol);
        else after(delay, () -> sfx.play(sound, vol));
    }

    private void thump(View v) {
        v.animate().cancel();
        v.setScaleX(1.06f);
        v.setScaleY(0.94f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(new OvershootInterpolator(3f)).start();
    }

    private void bounce(View v, long delay) {
        ObjectAnimator a = ObjectAnimator.ofFloat(v, View.TRANSLATION_Y,
                v.getTranslationY(), v.getTranslationY() - dp(8), v.getTranslationY());
        a.setStartDelay(delay);
        a.setDuration(380);
        a.setInterpolator(new DecelerateInterpolator());
        a.start();
    }

    private void pulse(View v) {
        v.animate().cancel();
        v.setScaleX(1f);
        v.setScaleY(1f);
        ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.06f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.06f, 1f));
        a.setDuration(420);
        a.start();
    }

    // ------------------------------------------------------------------
    // Score card
    // ------------------------------------------------------------------

    private void showScoreOverlay(boolean roundSummary) {
        roundSummaryMode = roundSummary || roundSummaryMode;
        overlaySort.setVisibility(View.GONE);

        StringBuilder sb = new StringBuilder();
        if (roundSummaryMode) {
            if (engine.isTiebreak()) sb.append("Tiebreak scored  ·  swipe up");
            else if (engine.roundNumber() >= GameEngine.TOTAL_ROUNDS) sb.append("Final round!  Swipe up for the result");
            else sb.append("▲  Swipe up to deal round ").append(engine.roundNumber() + 1);
        } else {
            sb.append("▲  Swipe up to return to the table");
        }
        labelScores.setText(sb.toString());

        int leader = leaderSeat();
        TextView[] st = {scoreGirl, scoreBoy, scoreCat, scorePlayer};
        Player.SeatKind[] kinds = {Player.SeatKind.GIRL, Player.SeatKind.BOY,
                Player.SeatKind.CAT, Player.SeatKind.HUMAN};

        boolean wasVisible = overlayScores.getVisibility() == View.VISIBLE;
        overlayScores.setVisibility(View.VISIBLE);
        if (!wasVisible) {
            overlayScores.setTranslationY(root.getHeight());
            overlayScores.animate().translationY(0f).setDuration(460)
                    .setInterpolator(new DecelerateInterpolator(2.2f)).start();
            sfx.play(Sfx.WHOOSH, 0.8f);
        }

        for (int i = 0; i < st.length; i++) {
            Player p = findSeat(kinds[i]);
            st[i].setTextColor(Style.INK);
            if (p == null) {
                st[i].setText("—\nsitting out");
                st[i].setTextColor(0xFF8A8478);
            }
            st[i].setRotation((i % 2 == 0 ? -1 : 1) * 3f);
            Style.popIn(st[i], 220 + i * 90L);
        }

        // Count the numbers up with a soft tick so the scores feel tallied.
        final long start = 380;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setStartDelay(roundSummaryMode && !wasVisible ? start : 120);
        a.setDuration(Pace.SCORE_COUNT);
        a.setInterpolator(new DecelerateInterpolator());
        final int[] lastTotal = {-1};
        final long[] lastTick = {0};
        a.addUpdateListener(an -> {
            float t = (float) an.getAnimatedValue();
            int sum = 0;
            for (int i = 0; i < st.length; i++) {
                Player p = findSeat(kinds[i]);
                if (p == null) continue;
                int r = Math.round(p.roundScore * t);
                int prevTotal = roundSummaryMode && !engine.isTiebreak()
                        ? p.cumulativeScore - p.roundScore : p.cumulativeScore;
                int total = roundSummaryMode && !engine.isTiebreak()
                        ? prevTotal + Math.round(p.roundScore * t) : p.cumulativeScore;
                sum += r + total;
                String crown = p.index == leader && t >= 1f ? "\n★ lowest" : "";
                st[i].setText("Round  +" + r + "\nTotal  " + total + crown);
            }
            long now = android.os.SystemClock.uptimeMillis();
            if (sum != lastTotal[0] && now - lastTick[0] > 55 && t < 1f) {
                sfx.play(Sfx.SCORE_TICK, 0.6f, 0.9f + t * 0.3f);
                lastTick[0] = now;
            }
            lastTotal[0] = sum;
        });
        a.start();
        if (roundSummaryMode) busy = false;
    }

    private int leaderSeat() {
        int best = Integer.MAX_VALUE, seat = -1, count = 0;
        for (Player p : engine.players()) {
            if (p.cumulativeScore < best) {
                best = p.cumulativeScore;
                seat = p.index;
                count = 1;
            } else if (p.cumulativeScore == best) {
                count++;
            }
        }
        return count == 1 ? seat : -1;
    }

    private Player findSeat(Player.SeatKind kind) {
        for (Player p : engine.players()) if (p.kind == kind) return p;
        return null;
    }

    private void dismissScores() {
        if (overlayScores.getVisibility() != View.VISIBLE) return;
        final boolean summary = roundSummaryMode;
        roundSummaryMode = false;
        sfx.play(Sfx.WHOOSH, 0.8f);
        overlayScores.animate().translationY(-root.getHeight()).setDuration(340)
                .setInterpolator(new AccelerateInterpolator(1.6f))
                .withEndAction(() -> {
                    overlayScores.setVisibility(View.GONE);
                    overlayScores.setTranslationY(0f);
                }).start();
        if (!summary) return;

        engine.acknowledgeRoundSummary();
        selectedHandIndex = -1;
        drawnHandIndex = -1;
        if (engine.isGameOver()) {
            after(260, this::showResult);
            return;
        }
        if (engine.phase() == GameEngine.Phase.ROUND_OVER) engine.startRound();
        if (engine.isGameOver()) {
            after(260, this::showResult);
            return;
        }
        pendingDeal = true;
        after(240, this::dealRound);
    }

    // ------------------------------------------------------------------
    // Sort overlay: tap-select, tap-other-swap, tap-same-deselect
    // ------------------------------------------------------------------

    private void openSortOverlay() {
        if (dealing || screenTable.getVisibility() != View.VISIBLE) return;
        if (busy && engine.currentIndex() == 0) return;
        GameEngine.Phase ph = engine.phase();
        if (ph == GameEngine.Phase.INSERT_PENDING) {
            nudge("Slot the new card in before sorting");
            return;
        }
        if (ph == GameEngine.Phase.ROUND_OVER || ph == GameEngine.Phase.GAME_OVER) return;
        sortSelected = -1;
        selectedHandIndex = -1;
        renderSortOverlay();
        overlaySort.setVisibility(View.VISIBLE);
        overlaySort.setTranslationY(root.getHeight() * 0.6f);
        overlaySort.setAlpha(0f);
        overlaySort.animate().translationY(0f).alpha(1f).setDuration(340)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
        sfx.play(Sfx.WHOOSH, 0.7f);
    }

    private void renderSortOverlay() {
        PlateLayout grid = (PlateLayout) overlaySort.findViewWithTag("sort_grid");
        grid.removeAllViews();

        List<Card> hand = engine.handOf(0);
        final float slotW = 0.145f, slotH = 0.095f;
        int cellH = Math.round(getResources().getDisplayMetrics().heightPixels * slotH);
        for (int slot = 0; slot < 13; slot++) {
            boolean right = slot < 7;
            int index = right ? slot : slot - 7;
            float x = right ? 0.548f : 0.307f;
            float y = (right ? 0.150f : 0.200f) + index * 0.100f;
            FrameLayout cell = new FrameLayout(this);
            cell.setClipChildren(false);
            cell.addView(cards.sortBack(), match());
            if (slot < hand.size()) {
                final int idx = slot;
                View cv = cards.face(hand.get(idx), engine.wildRank(), cellH);
                cv.setRotation(90f);
                if (idx == sortSelected) {
                    cv.setTranslationX(-dp(10));
                    cv.setElevation(dp(8));
                }
                cv.setOnClickListener(v -> onSortTap(idx));
                cell.addView(cv, match());
            }
            grid.add(cell, x, y, slotW, slotH);
        }
    }

    private void onSortTap(int index) {
        if (sortSelected < 0) {
            sortSelected = index;
            sfx.play(Sfx.SELECT);
        } else if (sortSelected == index) {
            sortSelected = -1;
            sfx.play(Sfx.DESELECT);
        } else {
            Collections.swap(engine.handOf(0), sortSelected, index);
            sortSelected = -1;
            sfx.play(Sfx.PLACE);
            commitHaptic(overlaySort);
        }
        tapHaptic(overlaySort);
        renderSortOverlay();
    }

    private void closeSortOverlay() {
        sortSelected = -1;
        sfx.play(Sfx.WHOOSH, 0.6f);
        overlaySort.animate().translationY(-root.getHeight() * 0.5f).alpha(0f).setDuration(280)
                .setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> {
                    overlaySort.setVisibility(View.GONE);
                    overlaySort.setTranslationY(0f);
                    overlaySort.setAlpha(1f);
                }).start();
        refreshTable();
    }

    // ------------------------------------------------------------------
    // Meld review overlay
    // ------------------------------------------------------------------

    private void showMeldOverlay() {
        LinearLayout panel = (LinearLayout) overlayMelds.findViewWithTag("panel");
        panel.removeAllViews();

        Style.OutlineText title = Style.headline(this, "MELDS ON THE TABLE", 24);
        panel.addView(title, rowParams(ViewGroup.LayoutParams.WRAP_CONTENT));

        int mini = dp(58);
        for (Player p : engine.players()) {
            TextView h = Style.label(this, Style.bold, 15, Style.GOLD_LIGHT);
            h.setGravity(Gravity.START);
            h.setText(p.name + (p.wentOut ? "  ·  went out" : ""));
            LinearLayout.LayoutParams hl = rowParams(ViewGroup.LayoutParams.WRAP_CONTENT);
            hl.topMargin = dp(14);
            panel.addView(h, hl);
            if (p.laidMelds.isEmpty()) {
                TextView none = Style.label(this, Style.ui, 13, 0xAAFFF4D6);
                none.setGravity(Gravity.START);
                none.setText("No melds laid yet");
                panel.addView(none, rowParams(ViewGroup.LayoutParams.WRAP_CONTENT));
                continue;
            }
            for (Meld m : p.laidMelds) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView tag = Style.label(this, Style.bold, 11, Style.CREAM);
                tag.setText(meldName(m));
                tag.setBackground(Style.chip(this, 0xFF3A2450));
                tag.setPadding(dp(8), dp(3), dp(8), dp(3));
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tl.rightMargin = dp(8);
                row.addView(tag, tl);
                int cw = Math.round(mini * 0.72f);
                for (int i = 0; i < m.cards.size(); i++) {
                    View cv = cards.face(m.cards.get(i), engine.wildRank(), mini);
                    LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(cw, mini);
                    if (i > 0) cl.leftMargin = -Math.round(cw * 0.35f);
                    row.addView(cv, cl);
                }
                LinearLayout.LayoutParams rl = rowParams(ViewGroup.LayoutParams.WRAP_CONTENT);
                rl.topMargin = dp(6);
                panel.addView(row, rl);
            }
        }

        Style.OutlineText close = Style.candy(this, "CONTINUE", Style.Candy.GREEN, 18);
        close.setId(R.id.btn_continue);
        close.setOnClickListener(v -> {
            sfx.play(Sfx.TAP);
            closeMeldOverlay();
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(200), dp(54));
        bl.gravity = Gravity.CENTER_HORIZONTAL;
        bl.topMargin = dp(20);
        panel.addView(close, bl);

        overlayMelds.setVisibility(View.VISIBLE);
        overlayMelds.setAlpha(0f);
        overlayMelds.animate().alpha(1f).setDuration(240).start();
        View frame = overlayMelds.findViewWithTag("frame");
        frame.setScaleX(0.85f);
        frame.setScaleY(0.85f);
        frame.animate().scaleX(1f).scaleY(1f).setDuration(380)
                .setInterpolator(new OvershootInterpolator(1.6f)).start();
    }

    private void closeMeldOverlay() {
        overlayMelds.animate().alpha(0f).setDuration(200)
                .withEndAction(() -> {
                    overlayMelds.setVisibility(View.GONE);
                    overlayMelds.setAlpha(1f);
                }).start();
        refreshTable();
        scheduleIdleHint();
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private LinearLayout.LayoutParams rowParams(int height) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        return lp;
    }

    private int dp(float value) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                getResources().getDisplayMetrics()));
    }

    /** A light tick for selection; respects the user's touch-feedback setting. */
    private void tapHaptic(View v) {
        try {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        } catch (RuntimeException ignored) {
            // best-effort
        }
    }

    /** A firmer click for committed plays (no VIBRATE permission needed). */
    private void commitHaptic(View v) {
        try {
            int c = Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.CONFIRM
                    : HapticFeedbackConstants.VIRTUAL_KEY;
            v.performHapticFeedback(c);
        } catch (RuntimeException ignored) {
            // best-effort
        }
    }

    /**
     * Soft golden spotlight behind the opponent who is acting. Fades in and out
     * instead of snapping, and only animates while visible.
     */
    private final class TurnGlowView extends View {
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int seat = -1;
        private int lastSeat = -1;
        private float level = 0f;
        private ValueAnimator fade;

        TurnGlowView() {
            super(MainActivity.this);
            setWillNotDraw(false);
            setClickable(false);
        }

        void setSpot(int s) {
            if (s == seat) return;
            seat = s;
            if (s > 0) lastSeat = s;
            if (fade != null) fade.cancel();
            fade = ValueAnimator.ofFloat(level, s > 0 ? 1f : 0f);
            fade.setDuration(s > 0 ? 260 : 320);
            fade.addUpdateListener(a -> {
                level = (float) a.getAnimatedValue();
                invalidate();
            });
            fade.start();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (engine == null || level <= 0.01f || lastSeat <= 0) return;
            if (screenTable.getVisibility() != View.VISIBLE) return;
            float[][] positions = seats();
            int index = lastSeat - 1;
            if (index < 0 || index >= positions.length) return;

            float width = getWidth();
            float cx = width * positions[index][0];
            float cy = getHeight() * positions[index][1];
            float base = width * (engine.opponentCount() == 1 ? 0.38f : 0.27f);
            double t = android.os.SystemClock.uptimeMillis() / 1000.0;
            float pulse = (float) Math.sin(t * Math.PI * 2.0 / 1.4);
            float radius = base * (0.95f + 0.04f * pulse);

            glowPaint.setStyle(Paint.Style.FILL);
            glowPaint.setShader(new RadialGradient(cx, cy, radius,
                    Color.argb((int) (95 * level), 255, 226, 120), Color.argb(0, 255, 200, 60),
                    Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius, glowPaint);
            glowPaint.setShader(null);

            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(Math.max(4f, width * 0.009f));
            int alpha = (int) ((120 + 50 * pulse) * level);
            glowPaint.setColor(Color.argb(Math.max(0, Math.min(255, alpha)), 255, 222, 110));
            canvas.drawCircle(cx, cy, radius * 0.64f, glowPaint);

            if (seat > 0) postInvalidateOnAnimation();
        }
    }
}
