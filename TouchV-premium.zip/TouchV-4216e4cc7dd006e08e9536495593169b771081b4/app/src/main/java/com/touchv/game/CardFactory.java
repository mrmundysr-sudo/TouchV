package com.touchv.game;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Builds card views. All lettering is sized from the card's pixel height so a
 * card reads the same in the fan, on the discard pile, in flight and in the
 * meld review, instead of fixed sp sizes that overflow small cards.
 *
 * Faces keep the locked layer-list drawables (card_face_*); backs use the
 * official card_back artwork clipped to rounded corners.
 */
public final class CardFactory {

    private final Context ctx;

    public CardFactory(Context ctx) {
        this.ctx = ctx;
    }

    public View back() {
        ImageView iv = Style.roundedImage(ctx, R.drawable.card_back, 0.075f);
        iv.setElevation(Style.dp(ctx, 2));
        iv.setContentDescription("Face-down card");
        return iv;
    }

    public View sortBack() {
        return Style.roundedImage(ctx, R.drawable.sort_slot_back, 0.075f);
    }

    /**
     * @param wildRank current wild rank, or -1 to skip the wild badge
     * @param heightPx the height the card will be laid out at
     */
    public View face(Card card, int wildRank, int heightPx) {
        float h = Math.max(heightPx, Style.dp(ctx, 40));
        FrameLayout f = new FrameLayout(ctx);
        f.setBackgroundResource(card.isJoker() ? R.drawable.card_face_joker : faceDrawable(card));
        f.setElevation(Style.dp(ctx, 2));
        f.setContentDescription(card.fullLabel()
                + (wildRank > 0 && card.isWild(wildRank) ? ", wild" : ""));

        boolean wild = wildRank > 0 && !card.isJoker() && card.rank == wildRank;
        int ink = card.isJoker() ? 0xFF6B4300 : 0xFF1C1424;

        // Centre: big chunky rank over the suit mark.
        LinearLayout center = new LinearLayout(ctx);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);

        if (card.isJoker()) {
            TextView star = text("★", Typeface.DEFAULT_BOLD, h * 0.30f, 0xFFD99A1E);
            center.addView(star, wrap());
            TextView word = text("JOKER", Style.display, h * 0.13f, ink);
            word.setLetterSpacing(0.06f);
            center.addView(word, wrap());
        } else {
            String rank = card.rankLabel();
            float rs = rank.length() > 1 ? h * 0.27f : h * 0.33f;
            TextView pip = text(rank, Style.display, rs, ink);
            center.addView(pip, wrap());
            if (card.suit == Card.Suit.PURPLE) {
                ImageView fleur = new ImageView(ctx);
                fleur.setImageResource(R.drawable.fleur_gold);
                fleur.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int s = Math.round(h * 0.24f);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
                lp.gravity = Gravity.CENTER_HORIZONTAL;
                center.addView(fleur, lp);
            } else {
                TextView suit = text(suitSymbol(card.suit), Typeface.DEFAULT_BOLD, h * 0.19f,
                        suitInk(card.suit));
                center.addView(suit, wrap());
            }
        }
        f.addView(center, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Corner indexes.
        String idx = card.isJoker() ? "★" : card.rankLabel();
        int cornerInk = card.isJoker() ? 0xFF8A5A0C : 0xFFFFFFFF;
        float cs = h * 0.135f;
        TextView tl = cornerText(idx, cs, cornerInk);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.leftMargin = Math.round(h * 0.06f);
        tlp.topMargin = Math.round(h * 0.035f);
        f.addView(tl, tlp);

        TextView br = cornerText(idx, cs, cornerInk);
        br.setRotation(180f);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        blp.rightMargin = Math.round(h * 0.06f);
        blp.bottomMargin = Math.round(h * 0.035f);
        f.addView(br, blp);

        if (wild) {
            // Gold rim + star badge so this round's wild cards are obvious at a glance.
            View rim = new View(ctx);
            GradientDrawable g = new GradientDrawable();
            g.setColor(0x00000000);
            g.setCornerRadius(Style.dp(ctx, 7));
            g.setStroke(Math.max(2, Math.round(h * 0.03f)), Style.GOLD_LIGHT);
            rim.setBackground(g);
            f.addView(rim, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView badge = text("★", Typeface.DEFAULT_BOLD, h * 0.12f, Style.BROWN);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColors(new int[]{Style.GOLD_LIGHT, Style.GOLD_DEEP});
            bg.setStroke(Math.max(1, Math.round(h * 0.012f)), Style.BROWN);
            badge.setBackground(bg);
            int bs = Math.round(h * 0.2f);
            FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(bs, bs, Gravity.TOP | Gravity.END);
            bl.topMargin = Math.round(h * 0.03f);
            bl.rightMargin = Math.round(h * 0.03f);
            f.addView(badge, bl);
        }
        return f;
    }

    private TextView cornerText(String s, float px, int color) {
        TextView t = text(s, Style.bold, px, color);
        if (color == 0xFFFFFFFF) t.setShadowLayer(px * 0.18f, 0, px * 0.06f, 0xAA000000);
        return t;
    }

    private TextView text(String s, Typeface tf, float px, int color) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTypeface(tf);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        return t;
    }

    private LinearLayout.LayoutParams wrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        return lp;
    }

    static String suitSymbol(Card.Suit suit) {
        switch (suit) {
            case GREEN: return "♣";
            case PINK: return "♥";
            case PURPLE: return "⚜";
            case ORANGE: return "♠";
            case GOLD: return "♦";
            default: return "✦";
        }
    }

    static int suitInk(Card.Suit suit) {
        switch (suit) {
            case GREEN: return 0xFF15552B;
            case PINK: return 0xFFB0174E;
            case PURPLE: return 0xFFFFC928;
            case ORANGE: return 0xFFB04208;
            case GOLD: return 0xFF8A5C08;
            default: return 0xFF825910;
        }
    }

    static int faceDrawable(Card card) {
        switch (card.suit) {
            case GREEN: return R.drawable.card_face_green;
            case PINK: return R.drawable.card_face_pink;
            case PURPLE: return R.drawable.card_face_purple;
            case ORANGE: return R.drawable.card_face_orange;
            case GOLD: return R.drawable.card_face_gold;
            default: return R.drawable.card_face_joker;
        }
    }
}
