package com.touchv.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.Random;

/**
 * Lightweight confetti burst for the You Win plate, in the suit colours.
 * Pieces flutter (spin + sway) and fall with drag; the loop stops itself.
 */
public final class ConfettiView extends View {

    private static final int[] COLORS = {
            0xFF2DBE60, 0xFFEA3E91, 0xFF8C3CE8, 0xFFF47A22, 0xFFE6B942, 0xFFFFFFFF,
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final RectF r = new RectF();
    private float[] x, y, vx, vy, rot, vr, sway, size;
    private int[] color;
    private int n;
    private long startMs, lastMs;
    private boolean running;

    public ConfettiView(Context c) {
        super(c);
        setClickable(false);
    }

    public void burst(int count) {
        n = count;
        x = new float[n];
        y = new float[n];
        vx = new float[n];
        vy = new float[n];
        rot = new float[n];
        vr = new float[n];
        sway = new float[n];
        size = new float[n];
        color = new int[n];
        float w = Math.max(1, getWidth());
        float h = Math.max(1, getHeight());
        float d = getResources().getDisplayMetrics().density;
        for (int i = 0; i < n; i++) {
            boolean left = (i & 1) == 0;
            x[i] = left ? w * 0.08f : w * 0.92f;
            y[i] = h * (0.30f + rnd.nextFloat() * 0.08f);
            float ang = (float) Math.toRadians(left ? -60 - rnd.nextFloat() * 25 : -120 + rnd.nextFloat() * 25);
            float sp = (650 + rnd.nextFloat() * 750) * d;
            vx[i] = (float) Math.cos(ang) * sp;
            vy[i] = (float) Math.sin(ang) * sp;
            rot[i] = rnd.nextFloat() * 360;
            vr[i] = (rnd.nextFloat() - 0.5f) * 900;
            sway[i] = rnd.nextFloat() * 6.28f;
            size[i] = (5 + rnd.nextFloat() * 5) * d;
            color[i] = COLORS[rnd.nextInt(COLORS.length)];
        }
        startMs = lastMs = System.currentTimeMillis();
        running = true;
        setVisibility(VISIBLE);
        postInvalidateOnAnimation();
    }

    public void stop() {
        running = false;
        n = 0;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!running || n == 0) return;
        long now = System.currentTimeMillis();
        float dt = Math.min(0.05f, (now - lastMs) / 1000f);
        lastMs = now;
        float t = (now - startMs) / 1000f;
        float d = getResources().getDisplayMetrics().density;
        float g = 900 * d;
        boolean any = false;
        for (int i = 0; i < n; i++) {
            vy[i] += g * dt;
            vx[i] *= (1 - 1.6f * dt);
            vy[i] *= (1 - 1.1f * dt);
            if (vy[i] > 240 * d) vy[i] = 240 * d; // terminal flutter speed
            x[i] += (vx[i] + (float) Math.sin(t * 5 + sway[i]) * 40 * d) * dt;
            y[i] += vy[i] * dt;
            rot[i] += vr[i] * dt;
            if (y[i] < getHeight() + 20 * d) any = true;
            float flip = (float) Math.abs(Math.cos(t * 7 + sway[i]));
            canvas.save();
            canvas.translate(x[i], y[i]);
            canvas.rotate(rot[i]);
            paint.setColor(color[i]);
            float s = size[i];
            r.set(-s, -s * 0.55f * flip - 0.5f, s, s * 0.55f * flip + 0.5f);
            canvas.drawRoundRect(r, s * 0.2f, s * 0.2f, paint);
            canvas.restore();
        }
        if (any && t < 6f) postInvalidateOnAnimation();
        else running = false;
    }
}
