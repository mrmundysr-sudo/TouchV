package com.touchv.game;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.text.TextPaint;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * TouchV! visual kit: bundled typefaces, the warm plum/gold palette taken from
 * the plate art, outlined "logo" lettering, HUD pills and candy buttons.
 *
 * Typefaces (SIL OFL, see /licenses):
 *   display = Lilita One   - chunky headline lettering that matches the TouchV! logo
 *   bold    = Fredoka Bold - card ranks, buttons
 *   ui      = Fredoka SemiBold - HUD and status copy
 *   hand    = Patrick Hand - handwriting on the score-card sticky notes
 */
public final class Style {

    // Palette (sampled to sit with the plates: warm wood, plum card backs, gold trim).
    public static final int PLUM = 0xFF241431;
    public static final int PLUM_GLASS = 0xE0221330;
    public static final int GOLD = 0xFFE8B84A;
    public static final int GOLD_LIGHT = 0xFFFFDA6B;
    public static final int GOLD_DEEP = 0xFFF08A1C;
    public static final int CREAM = 0xFFFFF4D6;
    public static final int BROWN = 0xFF4A2008;
    public static final int BROWN_MID = 0xFF7A3A0E;
    public static final int INK = 0xFF2A2340;
    public static final int GREEN_TOP = 0xFF7BE07A;
    public static final int GREEN_BOT = 0xFF23A050;
    public static final int GREEN_EDGE = 0xFF0E4A22;
    public static final int PLUM_TOP = 0xFFA678E6;
    public static final int PLUM_BOT = 0xFF6A35B0;
    public static final int PLUM_EDGE = 0xFF2C1054;

    public static Typeface display, bold, ui, hand;

    private Style() {
    }

    public static void init(Context ctx) {
        if (display != null) return;
        display = load(ctx, R.font.lilita_one, Typeface.DEFAULT_BOLD);
        bold = load(ctx, R.font.fredoka_bold, Typeface.DEFAULT_BOLD);
        ui = load(ctx, R.font.fredoka_semibold, Typeface.DEFAULT);
        hand = load(ctx, R.font.patrick_hand, Typeface.DEFAULT);
    }

    private static Typeface load(Context ctx, int id, Typeface fallback) {
        try {
            Typeface t = ctx.getResources().getFont(id);
            return t != null ? t : fallback;
        } catch (RuntimeException e) {
            return fallback;
        }
    }

    public static float dp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    // ------------------------------------------------------------------
    // Text
    // ------------------------------------------------------------------

    /**
     * Lettering with a rounded outline and a drop "depth" pass, like the plate
     * logos. Optional vertical gradient fill.
     */
    public static class OutlineText extends TextView {
        private int strokeColor = BROWN;
        private float strokeWidth;
        private float depth;
        private int gradTop = 0, gradBottom = 0;
        private boolean drawing;

        public OutlineText(Context c) {
            super(c);
            setIncludeFontPadding(false);
            setGravity(Gravity.CENTER);
            setLayerType(View.LAYER_TYPE_NONE, null);
        }

        public OutlineText outline(int color, float widthDp, float depthDp) {
            strokeColor = color;
            strokeWidth = dp(getContext(), widthDp);
            depth = dp(getContext(), depthDp);
            int p = (int) Math.ceil(strokeWidth + depth);
            setPadding(p, p, p, p);
            invalidate();
            return this;
        }

        public OutlineText gradient(int top, int bottom) {
            gradTop = top;
            gradBottom = bottom;
            invalidate();
            return this;
        }

        @Override
        public void invalidate() {
            if (!drawing) super.invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (strokeWidth <= 0) {
                super.onDraw(canvas);
                return;
            }
            drawing = true;
            int fill = getCurrentTextColor();
            TextPaint p = getPaint();
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeCap(Paint.Cap.ROUND);

            // depth pass
            if (depth > 0) {
                canvas.save();
                canvas.translate(0, depth);
                p.setStyle(Paint.Style.FILL_AND_STROKE);
                p.setStrokeWidth(strokeWidth * 2f);
                setTextColor(strokeColor);
                super.onDraw(canvas);
                canvas.restore();
            }
            // outline pass
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(strokeWidth * 2f);
            setTextColor(strokeColor);
            super.onDraw(canvas);
            // fill pass
            p.setStyle(Paint.Style.FILL);
            p.setStrokeWidth(0);
            setTextColor(fill);
            if (gradTop != 0) {
                float top = getTotalPaddingTop();
                float bottom = getHeight() - getTotalPaddingBottom();
                p.setShader(new LinearGradient(0, top, 0, bottom, gradTop, gradBottom,
                        Shader.TileMode.CLAMP));
            }
            super.onDraw(canvas);
            p.setShader(null);
            drawing = false;
        }
    }

    public static OutlineText headline(Context c, String text, float sp) {
        OutlineText t = new OutlineText(c);
        t.setTypeface(display);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(0xFFFFFFFF);
        t.outline(BROWN, Math.max(2f, sp / 9f), Math.max(1.5f, sp / 12f));
        t.gradient(GOLD_LIGHT, GOLD_DEEP);
        t.setLetterSpacing(0.02f);
        return t;
    }

    public static TextView label(Context c, Typeface tf, float sp, int color) {
        TextView t = new TextView(c);
        t.setTypeface(tf);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    // ------------------------------------------------------------------
    // Surfaces
    // ------------------------------------------------------------------

    /** Frosted plum HUD pill with a thin gold rim. */
    public static Drawable pill(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xE6302040, 0xE01A0E26});
        g.setCornerRadius(dp(c, 999));
        g.setStroke((int) dp(c, 1.5f), 0xCCE8B84A);
        return g;
    }

    /** Dark panel with gold border (meld review, result score strip). */
    public static Drawable panel(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xF22C1A3C, 0xF2170C22});
        g.setCornerRadius(dp(c, 22));
        g.setStroke((int) dp(c, 2.5f), GOLD);
        return g;
    }

    public static Drawable chip(Context c, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, 999));
        g.setStroke((int) dp(c, 1.2f), 0xAA000000);
        return g;
    }

    public enum Candy { GOLD, GREEN, PLUM }

    /** Glossy candy button body: dark lip, gradient face, top gloss. */
    public static Drawable candyBody(Context c, Candy kind) {
        int top, bot, edge;
        switch (kind) {
            case GREEN: top = GREEN_TOP; bot = GREEN_BOT; edge = GREEN_EDGE; break;
            case PLUM: top = PLUM_TOP; bot = PLUM_BOT; edge = PLUM_EDGE; break;
            default: top = GOLD_LIGHT; bot = GOLD_DEEP; edge = BROWN; break;
        }
        float r = dp(c, 999);
        GradientDrawable lip = new GradientDrawable();
        lip.setColor(edge);
        lip.setCornerRadius(r);
        GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{top, bot});
        face.setCornerRadius(r);
        face.setStroke((int) dp(c, 1.5f), edge);
        GradientDrawable gloss = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x88FFFFFF, 0x00FFFFFF});
        gloss.setCornerRadius(r);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{lip, face, gloss});
        int lipH = (int) dp(c, 4);
        ld.setLayerInset(1, 0, 0, 0, lipH);
        int gi = (int) dp(c, 3);
        ld.setLayerInset(2, (int) dp(c, 10), gi, (int) dp(c, 10), 0);
        ld.setLayerGravity(2, Gravity.TOP | Gravity.FILL_HORIZONTAL);
        ld.setLayerHeight(2, (int) dp(c, 14));
        return ld;
    }

    /** A candy button: outlined Lilita label on a glossy body with a squash on press. */
    public static OutlineText candy(Context c, String text, Candy kind, float sp) {
        OutlineText b = new OutlineText(c);
        b.setTypeface(display);
        b.setText(text);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setTextColor(0xFFFFFFFF);
        int edge = kind == Candy.GREEN ? GREEN_EDGE : kind == Candy.PLUM ? PLUM_EDGE : BROWN;
        b.outline(edge, 2f, 1.2f);
        b.setBackground(candyBody(c, kind));
        b.setLetterSpacing(0.03f);
        b.setContentDescription(text);
        b.setClickable(true);
        b.setFocusable(true);
        pressable(b);
        return b;
    }

    /** Squash-and-spring press feedback for any tappable view. */
    @SuppressLint("ClickableViewAccessibility")
    public static void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().cancel();
                    view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(70).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                            .setInterpolator(new OvershootInterpolator(3f)).start();
                    break;
                default:
                    break;
            }
            return false; // let click handling continue
        });
    }

    /** Pop a view in from small with a springy overshoot. */
    public static void popIn(View v, long delay) {
        v.setScaleX(0.6f);
        v.setScaleY(0.6f);
        v.setAlpha(0f);
        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(delay).setDuration(320)
                .setInterpolator(new OvershootInterpolator(2.2f)).start();
    }

    /** Short horizontal shake: "not yet". */
    public static void shake(View v) {
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(360);
        float amp = dp(v.getContext(), 7);
        a.addUpdateListener(an -> {
            float t = (float) an.getAnimatedValue();
            v.setTranslationX((float) (Math.sin(t * Math.PI * 6) * amp * (1 - t)));
        });
        a.start();
    }

    /** ImageView clipped to rounded card corners (hides the white JPEG corners). */
    public static ImageView roundedImage(Context c, int drawable, float radiusFraction) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(drawable);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                int w = view.getWidth(), h = view.getHeight();
                outline.setRoundRect(0, 0, w, h, Math.min(w, h) * radiusFraction);
            }
        });
        iv.setClipToOutline(true);
        return iv;
    }
}
