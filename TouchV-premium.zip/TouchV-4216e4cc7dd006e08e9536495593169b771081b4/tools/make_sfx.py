"""TouchV! sound pack synthesizer.

Every sound is generated from scratch (no samples), so the pack is fully
original and license-free. Palette: soft card-on-wood foley, warm marimba
ticks for UI, glassy bell chimes for turn cues, bright arpeggio stingers for
wins. A shared small-room reverb glues everything into one space.

Usage: python3 make_sfx.py OUT_DIR
Writes 44.1 kHz mono WAV masters to OUT_DIR/wav and OGG Vorbis to OUT_DIR/raw.
"""
import os
import subprocess
import sys

import numpy as np
from scipy import signal

SR = 44100
rng = np.random.default_rng(7)


# ---------------------------------------------------------------- helpers

def t_axis(dur):
    return np.arange(int(SR * dur)) / SR


def env_ad(n, attack, decay_tau, sustain_len=None):
    """Attack (s) then exponential decay with time-constant decay_tau (s)."""
    t = np.arange(n) / SR
    a = np.clip(t / max(attack, 1e-4), 0, 1)
    a = np.sin(a * np.pi / 2) ** 2  # smooth attack
    d = np.exp(-np.maximum(t - attack, 0) / decay_tau)
    return a * d


def fade(x, fin=0.002, fout=0.01):
    x = x.copy()
    ni, no = int(SR * fin), int(SR * fout)
    if ni:
        x[:ni] *= np.linspace(0, 1, ni)
    if no:
        x[-no:] *= np.linspace(1, 0, no) ** 2
    return x


def bandpass(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def lowpass(x, f, order=2):
    sos = signal.butter(order, f, btype="low", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def highpass(x, f, order=2):
    sos = signal.butter(order, f, btype="high", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def noise(dur):
    return rng.standard_normal(int(SR * dur))


def pad(x, dur):
    n = int(SR * dur)
    return np.concatenate([x, np.zeros(max(0, n - len(x)))])


def mix_at(base, x, at):
    i = int(SR * at)
    need = i + len(x)
    if need > len(base):
        base = np.concatenate([base, np.zeros(need - len(base))])
    base[i:i + len(x)] += x
    return base


_IR = None


def room(x, wet=0.14, size=0.38):
    """Small warm room: decaying filtered-noise impulse response."""
    global _IR
    if _IR is None or len(_IR) != int(SR * size):
        n = int(SR * size)
        t = np.arange(n) / SR
        ir = rng.standard_normal(n) * np.exp(-t / (size / 5.5))
        ir = lowpass(ir, 5200)
        ir[: int(SR * 0.006)] = 0  # pre-delay
        _IR = ir / np.sqrt(np.sum(ir ** 2))
    tail = signal.fftconvolve(x, _IR)[: len(x) + len(_IR)]
    dry = np.concatenate([x, np.zeros(len(tail) - len(x))])
    out = dry * (1 - wet * 0.5) + tail * wet
    # trim trailing silence
    thr = np.max(np.abs(out)) * 10 ** (-62 / 20)
    idx = np.where(np.abs(out) > thr)[0]
    end = idx[-1] + int(SR * 0.01) if len(idx) else len(out)
    return fade(out[:end], 0.0005, 0.03)


# ------------------------------------------------------------ instruments

def marimba(freq, dur=0.6, bright=1.0, vel=1.0):
    t = t_axis(dur)
    x = np.zeros_like(t)
    # tuned-bar partial ratios with faster decay for upper modes
    for ratio, amp, tau in ((1.0, 1.0, 0.22), (3.93, 0.32 * bright, 0.05),
                            (9.24, 0.12 * bright, 0.018)):
        f = freq * ratio
        if f < SR / 2.2:
            x += amp * np.sin(2 * np.pi * f * t) * np.exp(-t / (tau * (440 / freq) ** 0.25))
    # mallet strike
    strike = highpass(noise(0.012), 1800) * 0.18 * bright
    x[: len(strike)] += strike * np.linspace(1, 0, len(strike))
    return release(x * env_ad(len(t), 0.0015, 10) * vel)


def release(x, frac=0.35):
    """Smooth raised-cosine tail so truncated notes never click."""
    n = len(x)
    k = max(8, int(n * frac))
    x = x.copy()
    x[-k:] *= 0.5 * (1 + np.cos(np.linspace(0, np.pi, k)))
    return x


def bell(freq, dur=1.4, bright=1.0, vel=1.0):
    t = t_axis(dur)
    x = np.zeros_like(t)
    for ratio, amp, tau in ((1.0, 1.0, 0.65), (2.0, 0.45, 0.42), (2.76, 0.32 * bright, 0.28),
                            (5.40, 0.16 * bright, 0.12), (8.93, 0.07 * bright, 0.06)):
        f = freq * ratio
        if f < SR / 2.2:
            ph = rng.uniform(0, 2 * np.pi)
            x += amp * np.sin(2 * np.pi * f * t + ph) * np.exp(-t / tau)
    # gentle shimmer (chorused detune on fundamental)
    x += 0.18 * np.sin(2 * np.pi * freq * 1.003 * t) * np.exp(-t / 0.5)
    return release(x * env_ad(len(t), 0.002, 10) * vel)


def pluck(freq, dur=0.5, vel=1.0):
    """Soft Karplus-Strong pluck, used for warm harp-like sparkle."""
    n = int(SR * dur)
    p = int(SR / freq)
    buf = lowpass(rng.uniform(-1, 1, p), 6000)
    out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % p]
        buf[i % p] = 0.5 * (buf[i % p] + buf[(i + 1) % p]) * 0.996
    return out * vel


def note(name):
    names = {"C": -9, "D": -7, "E": -5, "F": -4, "G": -2, "A": 0, "B": 2}
    base = names[name[0]]
    i = 1
    if name[i] == "#":
        base += 1
        i += 1
    elif name[i] == "b":
        base -= 1
        i += 1
    octave = int(name[i:])
    return 440.0 * 2 ** ((base + (octave - 4) * 12) / 12)


# --------------------------------------------------------------- foley

def swish(dur=0.13, lo=1800, hi=7500, peak=0.35, vel=1.0):
    """Card sliding through air / across cloth."""
    n = int(SR * dur)
    x = noise(dur)
    # sweep the band upward slightly for motion
    a = bandpass(x, lo, hi, 2)
    t = np.arange(n) / n
    e = np.where(t < peak, (t / peak) ** 1.6, ((1 - t) / (1 - peak)) ** 2.2)
    return a * e * vel


def snap(vel=1.0, body=180, bright=1.0):
    """Card landing: crisp paper transient + soft wooden body."""
    tr = highpass(noise(0.018), 2500) * np.exp(-t_axis(0.018) / 0.003) * 0.9 * bright
    t = t_axis(0.12)
    bd = (np.sin(2 * np.pi * body * t) + 0.5 * np.sin(2 * np.pi * body * 2.3 * t)) \
        * np.exp(-t / 0.022) * 0.55
    x = np.zeros(len(t))
    x[: len(tr)] += tr
    x += bd
    x += lowpass(noise(0.12), 900) * np.exp(-t / 0.012) * 0.35
    return release(x * vel)


def wood_tick(freq=1900, vel=1.0, tau=0.012):
    t = t_axis(0.06)
    x = np.sin(2 * np.pi * freq * t) * np.exp(-t / tau)
    x += 0.4 * np.sin(2 * np.pi * freq * 2.71 * t) * np.exp(-t / (tau * 0.5))
    x += highpass(noise(0.06), 3000) * np.exp(-t / 0.002) * 0.25
    return release(x * vel)


# ---------------------------------------------------------------- sounds

def s_deal():
    x = swish(0.085, 2200, 8000, 0.45, 0.55)
    x = mix_at(x, snap(0.55, body=210, bright=0.9), 0.062)
    return room(x, 0.08)


def s_draw():
    # card lifted off the pile and slid toward the hand, with a tiny flip
    x = swish(0.17, 1500, 7000, 0.35, 0.8)
    x = mix_at(x, wood_tick(3400, 0.18, 0.004), 0.004)
    x = mix_at(x, highpass(noise(0.02), 3500) * np.exp(-t_axis(0.02) / 0.004) * 0.3, 0.11)
    return room(x, 0.1)


def s_place():
    x = swish(0.06, 2500, 8000, 0.5, 0.35)
    x = mix_at(x, snap(0.8, body=230, bright=0.8), 0.04)
    return room(x, 0.1)


def s_discard():
    x = swish(0.12, 1400, 6500, 0.55, 0.65)
    s = snap(1.0, body=150, bright=1.1)
    t = t_axis(0.3)
    table = (np.sin(2 * np.pi * 118 * t) * np.exp(-t / 0.05)
             + 0.35 * np.sin(2 * np.pi * 266 * t) * np.exp(-t / 0.03)) * 0.45
    table = release(table)
    x = mix_at(x, s, 0.095)
    x = mix_at(x, table, 0.095)
    return room(x, 0.14)


def s_select():
    x = marimba(note("E6"), 0.28, bright=0.6, vel=0.55)
    x = mix_at(x, swish(0.04, 3000, 9000, 0.3, 0.2), 0.0)
    return room(x, 0.1)


def s_deselect():
    x = marimba(note("B5"), 0.25, bright=0.5, vel=0.45)
    return room(x, 0.1)


def s_tap():
    x = marimba(note("G5"), 0.3, bright=0.8, vel=0.6)
    x = mix_at(x, marimba(note("G6"), 0.2, bright=0.4, vel=0.18), 0.0)
    return room(x, 0.12)


def s_nudge():
    # soft "not yet" double-tock, low and friendly
    x = marimba(note("D4"), 0.25, bright=0.6, vel=0.6)
    x = mix_at(x, marimba(note("A3"), 0.3, bright=0.6, vel=0.55), 0.09)
    return room(x, 0.1)


def s_your_turn():
    x = bell(note("E6"), 1.1, bright=0.7, vel=0.45)
    x = mix_at(x, bell(note("B6"), 1.0, bright=0.6, vel=0.38), 0.09)
    x = lowpass(x, 9000)
    return room(x, 0.2)


def s_opp_turn():
    # very soft single marimba: spotlight moves to an opponent
    x = marimba(note("C5"), 0.4, bright=0.4, vel=0.35)
    return room(x, 0.15)


def s_shuffle():
    # riffle: a dense train of tiny card ticks, accelerating then settling
    dur = 0.62
    x = np.zeros(int(SR * dur))
    tpos = 0.0
    k = 0
    while tpos < 0.48:
        tick = highpass(noise(0.006), 2000) * np.exp(-t_axis(0.006) / 0.0012)
        v = 0.25 + 0.25 * np.sin(np.pi * tpos / 0.48)
        x = mix_at(x, tick * v * rng.uniform(0.6, 1.0), tpos)
        tpos += 0.0085 + 0.004 * rng.random()
        k += 1
    x += swish(dur, 1200, 6000, 0.3, 0.18)[: len(x)]
    x = mix_at(x, snap(0.7, body=170), 0.5)
    return room(x, 0.12)


def s_round_start():
    x = swish(0.32, 900, 5000, 0.6, 0.35)
    for i, (n, at) in enumerate((("G5", 0.18), ("C6", 0.26), ("E6", 0.34))):
        x = mix_at(x, bell(note(n), 0.9, bright=0.6, vel=0.32), at)
    return room(lowpass(x, 10000), 0.2)


def s_score_tick():
    x = wood_tick(2600, 0.5, 0.008)
    return room(x, 0.06)


def s_meld():
    x = np.zeros(1)
    for i, n in enumerate(("C5", "E5", "G5", "C6")):
        x = mix_at(x, marimba(note(n), 0.5, bright=0.9, vel=0.55), i * 0.06)
    x = mix_at(x, bell(note("C7"), 0.8, bright=0.5, vel=0.18), 0.24)
    return room(x, 0.16)


def s_go_out():
    x = np.zeros(1)
    seq = ("C5", "E5", "G5", "C6", "E6", "G6")
    for i, n in enumerate(seq):
        x = mix_at(x, bell(note(n), 1.0, bright=0.8, vel=0.32), i * 0.055)
        x = mix_at(x, marimba(note(n), 0.4, bright=0.6, vel=0.25), i * 0.055)
    # sparkle tail
    for i in range(14):
        f = note("C7") * 2 ** (rng.integers(0, 12) / 12)
        x = mix_at(x, bell(f, 0.5, bright=0.3, vel=0.06), 0.35 + i * 0.035)
    return room(lowpass(x, 11000), 0.22)


def s_round_end():
    x = np.zeros(1)
    chords = ((("F4", "A4", "C5"), 0.0), (("G4", "B4", "D5"), 0.16), (("C5", "E5", "G5", "C6"), 0.34))
    for notes, at in chords:
        for n in notes:
            x = mix_at(x, marimba(note(n), 0.9, bright=0.7, vel=0.3), at + rng.uniform(0, 0.012))
    x = mix_at(x, bell(note("G6"), 1.2, bright=0.5, vel=0.12), 0.34)
    return room(x, 0.2)


def s_win():
    x = np.zeros(1)
    seq = (("C5", 0.0), ("E5", 0.09), ("G5", 0.18), ("C6", 0.27), ("G5", 0.40), ("C6", 0.49))
    for n, at in seq:
        x = mix_at(x, marimba(note(n), 0.6, bright=1.0, vel=0.45), at)
        x = mix_at(x, bell(note(n) * 2, 0.7, bright=0.5, vel=0.10), at)
    # held major chord with bells
    for n in ("C5", "E5", "G5", "C6", "E6"):
        x = mix_at(x, bell(note(n), 2.2, bright=0.7, vel=0.2), 0.62 + rng.uniform(0, 0.02))
    for i in range(24):
        f = note("C7") * 2 ** (rng.choice([0, 4, 7, 12, 16]) / 12)
        x = mix_at(x, bell(f, 0.45, bright=0.3, vel=0.05), 0.66 + i * 0.045)
    return room(lowpass(x, 11000), 0.24)


def s_lose():
    x = np.zeros(1)
    seq = (("G4", 0.0), ("F#4", 0.22), ("F4", 0.44), ("E4", 0.70))
    for n, at in seq:
        x = mix_at(x, marimba(note(n), 0.8 if n != "E4" else 1.2, bright=0.5, vel=0.5), at)
    # soft warm low chord under the last note
    for n in ("C3", "G3"):
        x = mix_at(x, marimba(note(n), 1.2, bright=0.3, vel=0.25), 0.70)
    return room(lowpass(x, 7000), 0.2)


def s_whoosh():
    dur = 0.28
    n = int(SR * dur)
    x = noise(dur)
    # time-varying bandpass sweep (low -> high) via short-block filtering
    out = np.zeros(n)
    blocks = 14
    for b in range(blocks):
        s, e = b * n // blocks, (b + 1) * n // blocks
        f = 500 * (8 ** (b / blocks))
        seg = bandpass(x[max(0, s - 512):e], f, min(f * 3, 16000), 2)[-(e - s):]
        out[s:e] = seg
    t = np.arange(n) / n
    out *= np.sin(np.pi * t) ** 1.5 * 0.4
    return room(out, 0.1)


SOUNDS = {
    "sfx_deal": (s_deal, -17),
    "sfx_draw": (s_draw, -16),
    "sfx_place": (s_place, -17),
    "sfx_discard": (s_discard, -14),
    "sfx_select": (s_select, -19),
    "sfx_deselect": (s_deselect, -21),
    "sfx_tap": (s_tap, -18),
    "sfx_nudge": (s_nudge, -19),
    "sfx_your_turn": (s_your_turn, -19),
    "sfx_opp_turn": (s_opp_turn, -24),
    "sfx_shuffle": (s_shuffle, -17),
    "sfx_round_start": (s_round_start, -18),
    "sfx_score_tick": (s_score_tick, -22),
    "sfx_meld": (s_meld, -16),
    "sfx_go_out": (s_go_out, -15),
    "sfx_round_end": (s_round_end, -16),
    "sfx_win": (s_win, -14),
    "sfx_lose": (s_lose, -16),
    "sfx_whoosh": (s_whoosh, -20),
}


def loudness_match(x, target_db):
    """Scale to a target short-term RMS (dBFS over the loudest 50 ms window),
    then hard-cap peaks at -1 dBFS so nothing clips."""
    win = int(SR * 0.05)
    if len(x) < win:
        x = pad(x, 0.06)
    sq = np.convolve(x ** 2, np.ones(win) / win, mode="valid")
    rms = np.sqrt(np.max(sq))
    g = 10 ** (target_db / 20) / max(rms, 1e-9)
    y = x * g
    peak = np.max(np.abs(y))
    cap = 10 ** (-1 / 20)
    if peak > cap:
        y *= cap / peak
    return y


def write(out_dir):
    wav_dir = os.path.join(out_dir, "wav")
    raw_dir = os.path.join(out_dir, "raw")
    os.makedirs(wav_dir, exist_ok=True)
    os.makedirs(raw_dir, exist_ok=True)
    from scipy.io import wavfile
    report = []
    for name, (fn, target) in SOUNDS.items():
        x = loudness_match(fn(), target)
        x = fade(x, 0.0008, 0.02)
        wp = os.path.join(wav_dir, name + ".wav")
        wavfile.write(wp, SR, (x * 32767).astype(np.int16))
        op = os.path.join(raw_dir, name + ".ogg")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wp, "-c:a", "libvorbis",
                        "-q:a", "6", op], check=True)
        report.append((name, len(x) / SR, 20 * np.log10(np.max(np.abs(x)) + 1e-9),
                       os.path.getsize(op)))
    for r in report:
        print("%-18s %5.2fs  peak %5.1f dBFS  %6d bytes" % r)


if __name__ == "__main__":
    write(sys.argv[1])
