# Touch V! — Full-app handoff for DeepSeek
**Status:** RULES + SCREENS + SKIN CONTRACT locked.  
**Date:** 2026-09-27 (updated same day — replace the earlier “skeleton only / landscape table” pass-on)  
**Name everywhere:** `TouchV!` (launcher label may show `Touch V!`)  
**Package:** `com.touchv.game`  
**Min SDK:** 26  
**Language:** Java, single-Activity. No Compose unless the project will not compile without it.  
**Phone size for every full-screen plate:** portrait **720 × 1600**. Coordinates only stay true at that size.

---

## What changed since the first pass-on (read this first)

| Old pass-on | Now locked |
|-------------|------------|
| DeepSeek = ugly skeleton only. Grok owns every pixel. | DeepSeek builds the **entire playable app**. Visuals must be **swap files**, not painted into code. Grok (or the user) drops final PNGs on top later. |
| Landscape green-felt table like Touch One | **Portrait photo plates.** Three different table plates, one per opponent count. |
| Title → separate opponent-pick screen | **Title plate IS the pick.** Dirt box under the wagon = 1 / 2 / 3 taps. One tap starts that count. No extra setup screen. |
| Fill order: 1 = boy, 2 = boy+cat, 3 = all | **This pass plates:** 1 = `girl-table`, 2 = `picnic-two` (boy + girl), 3 = `picnic-cat` (boy + cat + girl). |
| Opponent portrait ImageViews + thought-clouds on the table | Characters are **already in the plate photo**. Do **not** draw extra portraits or opponent clouds on the table this pass. |
| Round-score overlay as its own invented chrome | **Score-card plate** (portrait grid + sticky notes). Opens from your score bubble. Swipe up returns. After a round ends, show this plate; swipe up deals the next round (or result after round 11). |
| Play Again painted into win/loss | Separate transparent PNG `btn_play_again`. Same file on You Win and Try Again. Center of the view = center of mark 1. Button may be larger than the markup box. |

Do **not** simplify, reinterpret, or add house rules. Official rules are §6.  
Do **not** copy Touch One / Uno (no color-match discard, no “TOUCH ONE”, no +2 call penalty).

---

## 0. What DeepSeek is allowed to do

- Full compiling Android Studio project.
- Full 11-round loop, 2–4 seats (human + 1/2/3 AI), playable end to end.
- Placeholder **or** real plate PNGs — both must use the **exact drawable names in §8**.
- Overlay views for every tap target. Never bake a button, card, or score into a background bitmap.
- One rules engine used for going-out, final lay, scoring, and AI.
- Plain buttons `Declare Out` / `Lay Melds` if a plate has no mark for that step.
- Legal greedy AI is enough.

**Forbidden**
- Generating “final” title art, felt, card faces, portraits, win/loss scenes, or logos and treating them as finished.
- Painting 1/2/3, Play Again, cards, or scores into a background PNG.
- Inventing screens beyond the 8 plates + the two plain overlays in §5.
- Opponent cloud bubbles this pass.
- A sixth suit, Aces, Twos, playing onto other players’ melds, joint winners, a tie toggle.
- Renaming hook IDs.

If a slot looks empty, leave a colored rect + the locked ID. That is correct.

---

## 1. Skin contract (this is how visuals swap without breaking the app)

Everything pretty is a file in `res/drawable/`. Code only names the file.

1. **Full-screen plates** are `ImageView` (or the Activity content background) using `scaleType="fitXY"` on a 720×1600 bitmap. One plate visible at a time.
2. **Tap targets** are separate views sitting on top of the plate (`ImageButton`, `ImageView`, `View`). They use their own drawables or a transparent hit box.
3. **Swap rule:** replace the PNG, keep the filename, keep the view ID, keep layout params. App still runs.
4. **Do not** encode layout by drawing hotspots into the JPEG. The toolkit marks are where views go — not pixels inside the photo.
5. **Placeholder OK:** solid-color 720×1600 JPEG/PNG with the locked filename, plus a TextView label so the screen is identifiable. Ugly is fine.
6. **If the user attaches the unmarked plates,** put those files in `res/drawable/` under the locked names and still draw cards / 1-2-3 / Play Again / score bubble as overlays.
7. Card faces may be built from layers (border + color field + cream oval + pips) **or** one placeholder per suit + one joker. Later Grok replaces those drawables. Do not generate 55 unique pretty faces unless they are also named and fully replaceable.
8. `btn_play_again` is a transparent PNG overlay. Never flatten it into `bg_you_win` / `bg_try_again`.

Design-time target: 720 × 1600 portrait. Use `dp` derived from that, or raw px in a single `values/coords.xml` you can edit later.

---

## 2. Eight plates (do not invent a ninth)

| Plate | Drawable name | When it shows | Overlay views |
|-------|---------------|---------------|---------------|
| title / wagon-chase | `bg_title` | Launch. Also after Play Again. | Three taps in the **dirt box under the wagon**: opponents 1, 2, 3. Not portraits. Buttons drawn on top. One tap starts that count and opens the matching table. |
| girl-table | `bg_table_1` | 1 opponent | Fan, draw, discard, your score bubble |
| picnic-two | `bg_table_2` | 2 opponents (boy blue hoodie + girl purple hoodie) | Same four overlays |
| picnic-cat | `bg_table_3` | 3 opponents (boy + Himalayan cat + girl) | Same four overlays |
| sort | `bg_sort` | Swipe-up from the table (hand office) | Mark 1 = your cards. Portrait wood floor. Cards laid 7+6 **top-down turned 90°** so the player rotates the phone. |
| score-card | `bg_score_card` | Tap your score bubble, **or** automatically at end of each round | Stickies: girl, boy, cat, you. Skip a sticky when that seat is not in this match. Empty seat shows `N/A` in the same font as live scores. Swipe up = back to table / next deal. |
| you-win | `bg_you_win` | Human has the lowest cumulative after round 11 (and any tiebreak) | Play Again overlay |
| try-again | `bg_try_again` | Human does not | Play Again overlay (same `btn_play_again`) |

**Sort + score-card are overlays** on top of the live table (table state stays in memory). Swipe up closes them.

**No three-seat “generic felt” plate. No extra chrome screens.**

### Table overlay marks (same names on all three table plates)

1. `fan` — your cards  
2. `draw_pile` — facedown  
3. `discard_pile` — face-up  
4. `cloud_player` — your score bubble  

No mark 5. No opponent clouds. No opponent score bubbles on the table this pass.

### Title marks

1. Dirt under wagon = **WHERE** the 1 / 2 / 3 buttons sit. Three separate views.  
   - Tap 1 → `bg_table_1` (girl-table)  
   - Tap 2 → `bg_table_2` (picnic-two)  
   - Tap 3 → `bg_table_3` (picnic-cat)

### You Win / Try Again marks

1. Play Again — box left of the cat on the table. Center of `R.id.btn_play_again` = center of that box. Play Again → title plate.

### Score-card marks

1. girl’s score (sticky over girl, purple hoodie)  
2. boy’s score (sticky over boy, blue hoodie)  
3. cat’s score (sticky over Himalayan cat)  
4. your score (sticky over the Touch V! Me sign)  

Skip 1, 2, or 3 when that opponent is not seated this match. Still show the portrait if it is painted into the plate; the sticky reads `N/A`.

### Sort marks

1. your cards — tall portrait box. Tap = select one card. Tap a different card = swap those two. Tap the selected card again = deselect. Exit (swipe up) **freezes that fan order** until sort is opened again.

---

## 3. Screen flow (locked)

```
Title (pick 1 / 2 / 3)
  → matching table plate
  → 11 rounds on that plate
       • mid-round: swipe up → sort overlay → swipe up back
       • mid-round: tap your score bubble → score-card → swipe up back
       • end of each round: score-card (totals) → swipe up → next deal
  → after round 11 + tiebreak if needed:
       lowest cumulative is human → You Win
       else → Try Again
  → Play Again → Title
```

Tiebreak does **not** get its own picker. Same table plate. Only tied seats take turns; other seats stay in the picture but skip.

---

## 4. LOCKED — table and hand geometry

Still a **two-row fan**, even on a portrait plate.

- Top row: up to 7 cards, shallow bow (center higher than wings).
- Bottom row: up to 6 cards, dropped so each card’s **top-left pip stays visible**.
- Round 11 = 13 dealt + 1 drawn = 14 until discard. Show 13 in the fan; the 14th is the raised insert (or overflow at end of bottom row). No third row.
- Early rounds (3–6 cards): use only as much of the fan as needed.
- Fan is **play-only** for parked cards. No drag-reseat of parked cards.
- One card locked at a time.
- First tap on a parked card: select + slight raise. Lock must feel like the tap.
- While locked: slide on *other* parked cards hops the lock. Tap raised card or empty plate = deselect.
- **No** hold-to-reorder. **No** flick-to-discard. **No** second meaning on the same-card tap.

**Insert (the card just drawn this turn)**

- Arrives **raised / unlocked**.
- Slide into a gap and drop to park. Skip parks it at **end of fan**.
- After park it is a normal parked card.
- Mid-hand organize = sort overlay (especially rounds 1–8). Mid-turn on the table is insert + discard.

**Discard vs draw (not Uno)**

- Tap **draw pile** (your turn, not yet drawn) = take facedown card.
- Tap **discard pile** with **no card locked** and you have not drawn yet = take the **top discard** as your draw.
- Tap **discard pile** with a card **locked** and you **have already drawn** = discard that card and end the turn.
- Only the top discard may be taken. Never bury / stock-take.

**Seats (data, not extra portraits on the table)**

Human is always bottom. Official 1–4 players = human + 1/2/3 AI. No solitaire.

| Count picked on title | Table plate | Seated AI |
|-----------------------|-------------|-----------|
| 1 | girl-table | girl |
| 2 | picnic-two | boy + girl |
| 3 | picnic-cat | boy + cat + girl |

After someone goes out, laid-down Books/Runs for a seat may use a simple `meld_*` tray or a text list. Empty during hidden play. Do not invent a new full-screen plate for this.

---

## 5. LOCKED — extra overlays that are not photo plates

| Slot | ID | Purpose |
|------|----|---------|
| Meld review | `overlay_melds` | Going-out / final-turn laydown. Auto-detect + confirm. Plain is correct. |
| Declare Out / Lay Melds | `btn_declare_out` | Show when the validator says a legal out / final lay exists. |

---

## 6. LOCKED — cards as data

Five suits. Color is the suit. **No sixth color.**

| Enum | Color | Suit |
|------|--------|------|
| `CLUBS` or `GREEN` | green | clubs |
| `HEARTS` or `PINK` | pink | hearts |
| `FLEURS` or `PURPLE` | purple | fleurs |
| `SPADES` or `ORANGE` | orange | spades |
| `DIAMONDS` or `GOLD` | gold | diamonds |
| `JOKER` | — | joker (not a suit) |

Ranks: `3,4,5,6,7,8,9,10,J,Q,K` only. **No Aces. No Twos.**

Deck (exact):

- One 58-card deck = 5 suits × 11 ranks + 3 jokers  
- Play deck = **two** 58-card decks = **116** cards  
- 6 jokers  
- 22 cards per suit  

Placeholder face recipe: black border, color field, cream oval, center pip, corner pips.  
Joker: `@drawable/card_face_joker`.  
Back: `@drawable/card_back` (later: 5-point chrome fleur).

---

## 7. LOCKED — official rules (implement exactly)

### 7.1 Objective
11 rounds. Lowest **cumulative** score wins.  
Cards in valid Books/Runs = 0. Unused cards = points.

### 7.2 Rounds and wilds

| Round | Dealt | Wild rank |
|-------|-------|-----------|
| 1 | 3 | 3 |
| 2 | 4 | 4 |
| 3 | 5 | 5 |
| 4 | 6 | 6 |
| 5 | 7 | 7 |
| 6 | 8 | 8 |
| 7 | 9 | 9 |
| 8 | 10 | 10 |
| 9 | 11 | Jack |
| 10 | 12 | Queen |
| 11 | 13 | King |

Jokers are wild **every** round.  
Current-rank cards are wild **that round only**.

### 7.3 Values of unused cards
- Number card: face value (3–10)
- J = 11, Q = 12, K = 13
- Current wild rank (even if it is a 3–10 / J / Q / K): **20**
- Joker: **50**

### 7.4 Deal
Shuffle 116. Dealer selected. Deal 1-at-a-time clockwise. Remainder = face-down draw pile. Flip top card to start discard. Player left of dealer starts. Play clockwise. Next round: deal moves left, hand size +1, wild rank updates.

### 7.5 Normal turn (exact order)
1. Draw **one** card: top of draw **or** top of discard. Only the top discard may be taken.
2. Organize privately (hand stays hidden). No laying Books/Runs on the table yet.
3. Discard **one** card face up. Discard ends the turn.  
Must draw before discard. May discard a wild or joker.

### 7.6 Books
≥3 cards, **same rank**, any suits. Duplicates legal (two decks). Any number of wilds, wilds may be adjacent. Total size ≥3.

### 7.7 Runs
≥3 consecutive cards, **same suit**. Range is 3…K only. Cannot wrap. Cannot go below 3 or above King. Natural cards in the run must be that suit. Wilds may fill gaps, any count, may sit adjacent.

### 7.8 Going out
Only on your turn, after drawing.
- After the draw you have dealt+1 cards.
- Exactly **dealt** cards must form valid Books and/or Runs.
- The **extra drawn card is the discard** (it may have been playable).
- Lay Books/Runs face up, then discard the one remaining card.  
May not go out before drawing. May not play on another player’s melds. No partial table melds during normal play.

### 7.9 After someone goes out
That player’s turn is done (they score 0 this round).  
Every other player gets **exactly one** final turn: draw, may lay any valid Books/Runs they can make, must discard one. Then stop. Unused cards score.

### 7.10 Empty draw pile
Leave current top discard. Shuffle the rest of the discard pile face down as new draw. Continue.

### 7.11 Ties
**Option 2 only.**  
If two or more players share the lowest cumulative score after round 11, play one **6-card** tiebreak round with **only the tied players**. 6s are wild (hand size 6). Jokers still wild. Lowest score that round wins. If still tied, repeat the 6-card tiebreak until one player is lowest.  
No joint-winner option. No setup toggle.

### 7.12 AI skeleton
Legal random / greedy is enough: prefer taking discard if it completes a meld; otherwise draw; discard highest dead-wood; go out if able.

---

## 8. Interaction contract

```
phase: wait_draw | insert_pending | wait_discard | laying_out | not_my_turn

wait_draw (your turn, not yet drawn):
  tap draw pile              -> take facedown, insert_pending
  tap discard (no lock)      -> take top discard, insert_pending
  tap locked card / discard  -> IGNORE until drawn

insert_pending:
  slide into gap + drop      -> park, wait_discard
  skip / park end            -> park at end, wait_discard
  (optional) go straight to wait_discard with card still raised

wait_discard:
  tap parked card            -> lock/raise
  hop lock across fan
  tap discard with lock      -> if going_out_ok: laying_out then discard
                               else: discard, end turn
  tap own score bubble       -> score-card overlay
  swipe up                   -> sort overlay; exit freezes order
  cannot draw again

laying_out (going out or final turn):
  group hand into books/runs (auto-detect + confirm)
  leftover must be exactly 1 card if going out on a normal out
  confirm -> table those melds, discard last card

not_my_turn:
  opponent anim placeholder
```

**Going-out check:** after draw, if there exists a partition of exactly `dealtCount` cards into valid books/runs and exactly 1 leftover, player may declare out (or final-turn lay any subset).

One validator. Auto-detect + confirm is enough for skeleton. Later hand-grouping must call the same engine. No second rules copy.

---

## 9. Hook IDs (stable — do not rename)

```
R.drawable.bg_title
R.drawable.bg_table_1          // girl-table
R.drawable.bg_table_2          // picnic-two
R.drawable.bg_table_3          // picnic-cat
R.drawable.bg_sort
R.drawable.bg_score_card
R.drawable.bg_you_win
R.drawable.bg_try_again
R.drawable.btn_play_again      // transparent PNG, shared
R.drawable.card_back
R.drawable.card_face_green     // clubs
R.drawable.card_face_pink      // hearts
R.drawable.card_face_purple    // fleurs
R.drawable.card_face_orange    // spades
R.drawable.card_face_gold      // diamonds
R.drawable.card_face_joker
R.drawable.icon_fleur          // store / app icon slot

R.id.screen_title
R.id.btn_opp_1
R.id.btn_opp_2
R.id.btn_opp_3
R.id.screen_table
R.id.fan_top_row
R.id.fan_bottom_row
R.id.discard_pile
R.id.draw_pile
R.id.cloud_player              // your score bubble only
R.id.btn_declare_out
R.id.overlay_sort
R.id.overlay_scores
R.id.score_girl
R.id.score_boy
R.id.score_cat
R.id.score_player
R.id.screen_you_win
R.id.screen_try_again
R.id.btn_play_again
R.id.overlay_melds
R.id.meld_player
R.id.meld_opp_boy
R.id.meld_opp_cat
R.id.meld_opp_girl
R.id.label_round
R.id.label_wild
```

Fan overlap / card size = dimen resources.

Optional later (do not add this pass unless you need a view to compile):  
`cloud_opp_boy`, `cloud_opp_cat`, `cloud_opp_girl` — exist in data, **hidden**.

---

## 10. Clouds / hand office (this pass)

- **Your score bubble only** on the table. Shows card count and/or cumulative score.
- Tap bubble → score-card overlay.
- Swipe up on table → sort overlay (bulk arrange by tap-select / tap-swap).
- Exit sort **freezes fan order** until sort is opened again.
- Round chrome can be small text on the table or on the score-card: round 1–11, cards dealt, current wild rank, “Jokers always wild”.
- No color flash. No yell. No opponent clouds.

---

## 11. Out of scope

- Final painted art (Grok / user will drop files onto the names in §9)
- Opponent cloud bubbles
- Playing onto other players’ melds
- Store listing, ads, analytics
- Touch One call rules

---

## 12. DeepSeek deliverable

1. Compiling Android Studio project, package `com.touchv.game`.
2. Playable human+1 / +2 / +3, 11 rounds, tiebreak Option 2, placeholder or attached plates.
3. §8 interactions + §7 rules enforced. One meld engine.
4. README: run steps, hook ID list, **how to swap a plate** (replace file, keep name).
5. Source zip.

Bring that zip back here. Grok finish pass = drop real plates / card faces / Play Again on the locked names and nudge overlay boxes to the toolkit marks. No rewrite of rules if the engine is right.

---

## 13. Prompt you can paste to DeepSeek

> Build the entire Android app from this document. Java, single Activity, package com.touchv.game, minSdk 26, portrait 720×1600. Implement every rule in §7 and every interaction in §8. Use the eight plates and hook IDs in §9. Visuals must be replaceable PNG/JPEG files — overlays for cards, 1/2/3, score bubble, and Play Again. Do not paint those into the backgrounds. Do not invent screens. Do not add Uno rules. Placeholders are fine if I do not attach plates. Return a compiling project zip plus a README that lists every drawable I can swap.
