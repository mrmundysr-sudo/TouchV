# TouchV!

Skeleton Android build of **TouchV!** (launcher label may read `Touch V!`).

Java, single Activity, package `com.touchv.game`, minSdk 26, portrait.

This is the DeepSeek rules/interaction/placeholder-UI deliverable described in
`TOUCH-V-DEEPSEEK-HANDOFF.md`. Visuals are intentionally ugly: every plate,
card face, portrait and cloud is a solid-color placeholder. Grok replaces the
drawables named in §8/§9 one-to-one.

---

## 1. Run steps

Toolchain used to build and verify this tree:

- JDK 17 (Temurin 17.0.12)
- Android SDK Platform 34, Build-Tools 34.0.0, platform-tools
- Gradle 8.7

```bash
# point Gradle at your SDK (local.properties is git-ignored)
echo "sdk.dir=$ANDROID_HOME" > local.properties

export JAVA_HOME=/path/to/jdk-17
./gradlew :app:assembleDebug        # or: gradle :app:assembleDebug
```

Debug APK:

```
app/build/outputs/apk/debug/app-debug.apk
```

Install and launch:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.touchv.game/.MainActivity
```

Open the project in Android Studio: **Open** → select this folder → let it sync
(AGP 8.5.2, compileSdk 34).

---

## 2. User override: portrait 720x1600

`TOUCH-V-DEEPSEEK-HANDOFF.md` §1 says **landscape table**. The build request for
this delivery overrides that:

- **Portrait 720x1600 is authoritative for this build.**
- `AndroidManifest.xml` pins `android:screenOrientation="portrait"`.
- The table is laid out as weighted vertical sections (header / opponent seats /
  centre piles / player area / action row) so it fits 360x800dp without a
  landscape pixel budget. A future landscape pass only needs to change the
  section weights and the fan card widths.

No other handoff rule was changed.

---

## 3. Screens and flow

`Title → Pick opponents 1/2/3 → Table (11 rounds) → round score card after each
hand → Win/Loss → Play Again → Title`

| Screen | ID | Notes |
|--------|----|-------|
| Title | `screen_title` | `bg_title` plate + `TouchV!` label |
| Opponent pick | `screen_setup` | `btn_opp_1` / `btn_opp_2` / `btn_opp_3` |
| Table | `screen_table` | gameplay; background `bg_table_1/2/3` by seat count |
| Round score | `overlay_scores` | after every round, `CONTINUE` |
| Win / loss | `screen_result` | `YOU WIN` / `TRY AGAIN`, `btn_play_again` |
| Meld review | `overlay_melds` | laid melds for every seat |
| Sort | `overlay_sort` | swipe-up sorter |

Unused seats are hidden, not drawn as empty chairs.

---

## 4. Rules implemented (§6)

- 116-card deck: two 58-card decks = 5 suits × ranks 3..K (11 ranks) + 3 jokers.
  6 jokers, 22 cards per suit, **no Aces, no Twos**, no Uno rules.
- 11 rounds. Round *n* deals *n+2* cards and that count is the Wild rank
  (11 = Jack, 12 = Queen, 13 = King). Jokers are wild every round; the
  current-rank cards are wild that round only.
- Values of unused cards: number = face value, J/Q/K = 11/12/13, current wild
  rank = 20, joker = 50.
- Deal 1-at-a-time clockwise, flip top card to start the discard, player left of
  the dealer starts, deal moves left each round.
- Books: ≥3 cards of the same rank, any suits, duplicates legal, any number of
  wilds. Runs: ≥3 consecutive same-suit cards, range 3..K only, no wrap, wilds
  may fill gaps.
- Going out: only on your turn after drawing, exactly `dealt` cards form melds,
  the extra drawn card is the final discard.
- After a player goes out, every other player gets exactly one final turn
  (draw, optional lay, mandatory discard).
- Empty draw pile: keep the top discard, shuffle the rest into a new draw pile.
- Ties: **Option 2 only** — a 6-card tiebreak round with only the tied seats,
  6s wild, lowest round score wins; repeat until one player is lowest.

### One shared validator

`Meld.java` is the only rules engine for melds. It is used by:

- going-out check (`Meld.canGoOut`)
- final-turn lay (`Meld.bestPartition` / `Meld.scoreLeftovers`)
- round scoring (`Meld.bestPartition`)
- the AI (`Meld.bestPartition`, `Meld.canGoOut`)

There is no second copy of the book/run rules anywhere.

---

## 5. Interaction (§7)

Every tap target is an overlay view with a stable ID.

- **wait_draw** — tap `draw_pile` for a facedown card; tap `discard_pile` with no
  card locked for the top discard. Locked-card taps are ignored until drawn.
- **insert_pending** — the drawn card arrives raised. Tap a gap to slide it in,
  tap the raised card again or `btn_park_end` to park it at the end of the fan.
- **wait_discard** — tap a parked card to lock/raise it; tap another to hop the
  lock; tap the same card again to deselect. Tap `discard_pile` with a lock to
  discard and end the turn (declaring out instead if the hand qualifies).
- **laying_out** — `btn_declare_out` (going out) and `btn_lay_melds` (final
  turn) auto-detect with the shared validator, then show `overlay_melds`.
- **sort overlay** — swipe up on the fan (or tap your own cloud) to open.
  Tap-select a card, tap another to swap, tap the same card to deselect.
  Exit freezes the fan order.
- Opponent cloud short-press shows that seat's cumulative score only.

---

## 6. Hook IDs (§8)

Drawables:

```
bg_title            bg_table            bg_table_1         bg_table_2
bg_table_3          card_back           card_face_green     card_face_pink
card_face_purple    card_face_orange    card_face_gold      card_face_joker
opp_boy             opp_cat             opp_girl            icon_fleur
btn_plate           cloud_plate         slot_plate
```

IDs:

```
screen_title        screen_setup        screen_table        screen_result
overlay_scores      overlay_melds       overlay_sort
fan_top_row         fan_bottom_row      discard_pile        draw_pile
cloud_player        cloud_opp_boy       cloud_opp_cat       cloud_opp_girl
meld_player         meld_opp_boy        meld_opp_cat        meld_opp_girl
label_round         label_wild          label_status        label_scores
slot_player         slot_opp_boy        slot_opp_cat        slot_opp_girl
portrait_player     portrait_opp_boy    portrait_opp_cat    portrait_opp_girl
count_player        count_opp_boy       count_opp_cat       count_opp_girl
btn_opp_1           btn_opp_2           btn_opp_3           btn_declare_out
btn_lay_melds       btn_park_end        btn_continue        btn_play_again
```

---

## 7. Replacing placeholders (Grok)

1. Drop the new bitmap into `app/src/main/res/drawable/` using **exactly** the
   filename from the list above (for example `card_face_green.png` replaces
   `card_face_green.xml`). Delete the old `.xml` of the same name, or the build
   fails on a duplicate resource.
2. Keep the `card_face_*` / `card_back` aspect close to a playing card
   (roughly 5:7) so the fan geometry still reads.
3. `opp_*` portraits are drawn at 62x62dp in the seat; supply a square image.
4. `bg_table` is the title/base felt; `bg_table_1/2/3` are the 1/2/3-opponent
   table backgrounds.
5. `icon_fleur` feeds the adaptive launcher icon
   (`mipmap-anydpi-v26/ic_launcher.xml`).
6. Card size and fan overlap are `dimen` resources in
   `res/values/dimens.xml` (`card_w`, `card_h`, `fan_top_overlap`,
   `fan_bottom_overlap`, `fan_lift`, `pile_w/h`, `seat_w/h`, `cloud_w/h`), so the
   fan can be retuned for the final art without touching Java.

No Java change is required to swap any of these.

---

## 8. Source layout

```
app/src/main/java/com/touchv/game/
  Card.java        card data, suits, values, labels
  Deck.java        116-card build + shuffle
  Meld.java        the single book/run validator + partition search
  Player.java      seat, hand, laid melds, scores
  GameEngine.java  rounds, deal, turns, going out, scoring, AI, tiebreak
  MainActivity.java all screens, overlays, interaction, placeholder rendering
app/src/main/res/
  drawable/        placeholder plates, card faces, portraits
  values/          colors, dimens, strings, styles, ids
  mipmap-anydpi-v26/ic_launcher.xml
selftest/          headless engine tests (no Android SDK needed)
  run.sh           compiles the pure-Java engine and runs every test
  MeldTest.java    deck size/suits/jokers, book+run validation, values, scoring
  GameSim.java     90 full games across 1/2/3 opponents
  HumanPathTest.java drives seat 0 through the exact MainActivity call sequence
  TiebreakTest.java forced Option 2 tiebreaks (asserts the 6-card deal)
```

Run the engine tests with `./selftest/run.sh` (uses `javac`/`java` on PATH).

---

## 9. Verification performed

- `gradle :app:assembleDebug` builds clean (AGP 8.5.2 / Gradle 8.7 / JDK 17).
- A clean-room build was done from the shipped `TouchV-source.zip` in an empty
  directory: `BUILD SUCCESSFUL`.
- `aapt2 dump badging` confirms package `com.touchv.game`, minSdk 26,
  targetSdk 34, label `TouchV!`.
- All `drawable/` and `R.id` hooks above are present in the packaged APK.
- `./selftest/run.sh` passes: deck = 116 with 6 jokers and 22 per suit,
  book/run validation, values, going-out partitions, scoring example, 90
  full-game simulations, the human UI call path, and forced Option 2 tiebreaks
  confirming a 6-card deal and a single winner.
- `gradle :app:lintDebug` completes without a build failure.
