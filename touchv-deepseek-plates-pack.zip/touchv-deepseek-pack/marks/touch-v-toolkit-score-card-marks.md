# Touch V! toolkit — score card

Screen: score card / portrait scores
Marked: artifacts/touch-v-toolkit-score-card-marked.png
Unmarked: artifacts/touch-v-toolkit-score-card-unmarked.png

Marks (user):
- 1 = girl's score (sticky note over girl, purple hoodie)
- 2 = boy's score (sticky note over boy, blue hoodie)
- 3 = cat's score (sticky note over Himalayan cat)
- 4 = your score (sticky note over Touch V! Me sign)

Notes:
- Portrait grid, not table felt.
- Access: tap your score bubble (user cloud) on the table plate. This overlay comes up.
- Exit: swipe up, back to gameplay.
- No opponent clouds.
- Skip a seat’s mark when that opponent is not in the picture.
