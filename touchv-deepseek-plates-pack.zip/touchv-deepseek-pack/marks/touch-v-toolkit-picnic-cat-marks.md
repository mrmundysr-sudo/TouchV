# Touch V! toolkit plate — picnic-cat

Plate: outdoor picnic table under pavilion. Boy blue hoodie (left), Himalayan cat center, girl purple hoodie (right).
Source marked file: artifacts/touch-v-toolkit-picnic-cat-marked.png
Unmarked asset: artifacts/touch-v-toolkit-picnic-cat-unmarked.png

Marks (user-named only):

1 = your cards
2 = draw pile (facedown)
3 = discard pile (face-up)
4 = your score bubble

No mark 5 on this plate. No opponent clouds this pass.
