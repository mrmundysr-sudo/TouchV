# Touch V! toolkit plate — title (wagon-chase)

Plate: wagon-chase portrait. Title logo top. Boy, girl, and goggled cat in red wagon.
Source marked file: artifacts/touch-v-toolkit-title-marked.png
Unmarked asset: artifacts/touch-v-toolkit-title-unmarked.png

Marks (user-named only):

1 = opponents 1, 2, or 3
  Box on dirt under the wagon (same job as Touch One opponent-count select).
  Not character portraits.

No other marks on this plate this pass.
