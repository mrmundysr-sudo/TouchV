# Touch V! picnic-two toolkit plate

Marked: artifacts/touch-v-toolkit-picnic-two-marked.png
Unmarked: artifacts/touch-v-toolkit-picnic-two-unmarked.png

1 = your cards
2 = draw pile (facedown)
3 = discard pile (face-up)
4 = your score bubble

No mark 5 on this plate.
No opponent score bubbles marked this pass.
