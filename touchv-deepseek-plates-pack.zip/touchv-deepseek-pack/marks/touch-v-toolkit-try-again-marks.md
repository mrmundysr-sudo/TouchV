# Touch V! toolkit plate — try-again

Plate: Try Again portrait. Boy blue hoodie, girl purple hoodie, Himalayan cat on table, TRY AGAIN title.
Source marked file: artifacts/touch-v-toolkit-try-again-marked.png
Unmarked asset: artifacts/touch-v-toolkit-try-again-unmarked.png

Marks (user-named only):

1 = Play Again
  Blue box on the table to the left of the cat.

No other marks on this plate this pass.
