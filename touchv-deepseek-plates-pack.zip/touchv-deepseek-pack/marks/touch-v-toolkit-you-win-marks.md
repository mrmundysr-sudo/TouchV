# Touch V! toolkit plate — you-win

Plate: You Win portrait. Boy blue hoodie, girl purple hoodie, Himalayan cat on table, confetti, YOU WIN title.
Source marked file: artifacts/touch-v-toolkit-you-win-marked.png
Unmarked asset: artifacts/touch-v-toolkit-you-win-unmarked.png

Marks (user-named only):

1 = Play Again
  Blue box on the table to the left of the cat.

No other marks on this plate this pass.
