# Touch V! — card-sort toolkit plate

Screen: swipe-up overlay / card sort
Phone: portrait 720 × 1600
Plate: wood floor, cards 7+6 top-down turned 90° so player rotates phone

Files:
- artifacts/touch-v-toolkit-sort-marked.png
- artifacts/touch-v-toolkit-sort-unmarked.png

Marks:
1. your cards — tall portrait box; tap select, tap other swap, tap same deselect

This pass: no opponent cloud bubbles.
