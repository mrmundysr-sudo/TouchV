# Touch V! girl-table toolkit marks
Source: user marked plate (this rebuild)
Filed: artifacts/touch-v-toolkit-girl-table-marked.png
Unmarked plate: not sent yet

## Marks (user-named only)

1 = your cards
2 = draw pile (facedown)
3 = discard pile (face-up)
4 = your score bubble

No other marks on this plate.
