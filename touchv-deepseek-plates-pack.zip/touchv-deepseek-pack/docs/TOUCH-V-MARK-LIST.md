# Touch V! mark list

Owner: user names screens and marks. Grok files only what is sent.
Vault: Google Drive folder TouchV (id 1C_0RGMbdlsEopF5S6oAgVZoMTWum_e4_).
Rebuilt: 2026-09-27 from Drive files only. New chat disk starts empty — Drive is source of truth.
This pass: no opponent clouds.

## Complete set — 8 plates (user lock 2026-09-27)

No three-seat table. No extra overlays. Do not invent screens.

### sort
- marked: touch-v-toolkit-sort-marked.png
- unmarked: touch-v-toolkit-sort-unmarked.png
- marks:
  - 1 = your cards (tap select, tap other swap, tap same deselect)
- notes: swipe-up overlay. Portrait wood floor. Cards 7+6 top-down turned 90° so player rotates phone.

### girl-table
- marked: touch-v-toolkit-girl-table-marked.png
- unmarked: touch-v-toolkit-girl-table-unmarked.png
- marks:
  - 1 = your cards
  - 2 = draw pile (facedown)
  - 3 = discard pile (face-up)
  - 4 = your score bubble
- notes: No mark 5. No opponent clouds.

### picnic-two
- marked: touch-v-toolkit-picnic-two-marked.png
- unmarked: touch-v-toolkit-picnic-two-unmarked.png
- marks:
  - 1 = your cards
  - 2 = draw pile (facedown)
  - 3 = discard pile (face-up)
  - 4 = your score bubble
- notes: Boy blue hoodie + girl purple hoodie. No mark 5. No opponent clouds.

### picnic-cat
- marked: touch-v-toolkit-picnic-cat-marked.png
- unmarked: touch-v-toolkit-picnic-cat-unmarked.png
- marks:
  - 1 = your cards
  - 2 = draw pile (facedown)
  - 3 = discard pile (face-up)
  - 4 = your score bubble
- notes: Boy blue hoodie + Himalayan cat + girl purple hoodie. No mark 5. No opponent clouds.

### title / wagon-chase
- marked: touch-v-toolkit-title-marked.png
- unmarked: touch-v-toolkit-title-unmarked.png
- marks:
  - 1 = opponents 1, 2, or 3
- notes: Box on dirt under wagon. Opponent COUNT select. Not character portraits.

### you-win
- marked: touch-v-toolkit-you-win-marked.png
- unmarked: touch-v-toolkit-you-win-unmarked.png
- marks:
  - 1 = Play Again
- notes: Blue box on table left of the cat. Same tap as try-again Play Again.

### try-again
- marked: touch-v-toolkit-try-again-marked.png
- unmarked: touch-v-toolkit-try-again-unmarked.png
- marks:
  - 1 = Play Again
- notes: Blue box on table left of the cat. Same tap as you-win Play Again.

### score-card
- marked: touch-v-toolkit-score-card-marked.png
- unmarked: touch-v-toolkit-score-card-unmarked.png
- marks:
  - 1 = girl's score
  - 2 = boy's score
  - 3 = cat's score
  - 4 = your score
- notes: Portrait grid. Sticky notes on each portrait / Me sign. Open by tapping your score bubble on a table plate. Swipe up returns to gameplay. Skip a seat’s mark when that opponent is not in the picture.

## End of list
